import type {
  CrewMember,
  Language,
  OpticSystemId,
  PersonnelEffects,
  PlanetData,
  ScienceObjectiveId,
  ShipConfig,
  ShipLivery,
  ShipMetrics,
  ShipPartOption,
  ShuttleRoomId,
  ShuttleSpecialist,
  WavelengthId,
} from '../types/game';

export const SHIP_PARTS: ShipPartOption[] = [
  {
    id: 'eng_ion',
    category: 'engine',
    name: { ar: 'محرك أيوني قياسي MK-I', en: 'Ion Thruster MK-I' },
    desc: { ar: 'دفع اقتصادي وموثوق للمدار القريب.', en: 'Balanced low-mass ion propulsion.' },
    cost: 40,
    mass: 620,
    powerDelta: -12,
    deltaV: 3400,
    reliabilityBonus: 4,
    tier: 1,
  },
  {
    id: 'eng_vasimir',
    category: 'engine',
    name: { ar: 'دفع بلازما VASIMR', en: 'VASIMR Plasma Drive' },
    desc: { ar: 'تسارع عالٍ لرحلات الكواكب العميقة.', en: 'High-thrust magnetoplasma interplanetary drive.' },
    cost: 85,
    mass: 840,
    powerDelta: -22,
    deltaV: 5600,
    reliabilityBonus: 7,
    tier: 2,
  },
  {
    id: 'eng_fusion',
    category: 'engine',
    name: { ar: 'مفاعل اندماج نوفا X9', en: 'NOVA Fusion Core X9' },
    desc: { ar: 'سرعة قصوى واخترق العواصف الأيونية بثبات.', en: 'Top-tier fusion impulse engineered for deep storms.' },
    cost: 145,
    mass: 1050,
    powerDelta: -30,
    deltaV: 8400,
    reliabilityBonus: 12,
    tier: 3,
  },
  {
    id: 'sol_wings',
    category: 'solar',
    name: { ar: 'أجنحة شمسية مزدوجة', en: 'Dual Solar Wings' },
    desc: { ar: 'ألواح خفيفة لتوليد طاقة مستقرة.', en: 'Lightweight photovoltaic arrays.' },
    cost: 30,
    mass: 240,
    powerDelta: 38,
    deltaV: 0,
    reliabilityBonus: 4,
    tier: 1,
  },
  {
    id: 'sol_rtg',
    category: 'solar',
    name: { ar: 'مولد نظائر نووية RTG', en: 'Tri-Core RTG Reactor' },
    desc: { ar: 'طاقة متواصلة حتى في القطاع المظلم.', en: 'Uninterrupted power deep beyond solar orbit.' },
    cost: 75,
    mass: 410,
    powerDelta: 68,
    deltaV: 0,
    reliabilityBonus: 9,
    tier: 2,
  },
  {
    id: 'sol_quantum',
    category: 'solar',
    name: { ar: 'مكثف فراغي كمومي', en: 'Quantum Zero-Point Array' },
    desc: { ar: 'توليد طاقة فائق لدعم الدروع والمدافع.', en: 'Abundant output supporting heavy shields and plasma.' },
    cost: 125,
    mass: 490,
    powerDelta: 105,
    deltaV: 0,
    reliabilityBonus: 12,
    tier: 3,
  },
  {
    id: 'hull_ti',
    category: 'hull',
    name: { ar: 'هيكل تيتانيوم خفيف', en: 'Titanium Alloy Frame' },
    desc: { ar: 'حماية قياسية وخفة في المناورة.', en: 'Standard orbital titanium-carbon chassis.' },
    cost: 35,
    mass: 750,
    powerDelta: -4,
    deltaV: 0,
    reliabilityBonus: 5,
    tier: 1,
  },
  {
    id: 'hull_aegis',
    category: 'hull',
    name: { ar: 'درع إيجيس الحراري', en: 'Aegis Ablative Armor' },
    desc: { ar: 'يقلل ضرر التوهجات الشمسية والكويكبات.', en: 'Reinforced shielding against flares and debris.' },
    cost: 80,
    mass: 980,
    powerDelta: -10,
    deltaV: 0,
    reliabilityBonus: 11,
    tier: 2,
  },
  {
    id: 'hull_graphene',
    category: 'hull',
    name: { ar: 'درع غرافين مغناطيسي', en: 'Magneto-Graphene Bastion' },
    desc: { ar: 'أقصى مقاومة للعواصف الأيونية والثقب الأسود.', en: 'Peak deflector matrix for ion storms and singularities.' },
    cost: 130,
    mass: 1120,
    powerDelta: -14,
    deltaV: 0,
    reliabilityBonus: 16,
    tier: 3,
  },
  {
    id: 'sen_lidar',
    category: 'sensor',
    name: { ar: 'رادار ليدار + مدفع تعدين I', en: 'LiDAR + Mining Pulse I' },
    desc: { ar: 'مسح أساسي للكواكب وتفتيت الصخور.', en: 'Basic surface LiDAR and asteroid mining beam.' },
    cost: 25,
    mass: 160,
    powerDelta: -6,
    deltaV: 0,
    reliabilityBonus: 3,
    tier: 1,
  },
  {
    id: 'sen_spectro',
    category: 'sensor',
    name: { ar: 'مطياف عميق + بلازما II', en: 'Deep Spectro + Plasma II' },
    desc: { ar: 'تحليل أسرع ومعدل إطلاق مضاعف.', en: 'Rapid mineral spectroscopy and twin plasma bolts.' },
    cost: 65,
    mass: 230,
    powerDelta: -11,
    deltaV: 0,
    reliabilityBonus: 6,
    tier: 2,
  },
  {
    id: 'sen_tachyon',
    category: 'sensor',
    name: { ar: 'مسبار تاكيون + مدفع فائق', en: 'Tachyon Array + Overdrive' },
    desc: { ar: 'رصد إشارة 2089 وأقوى تسليح تعديني.', en: '2089 signal decoder and rapid-fire plasma overdrive.' },
    cost: 110,
    mass: 280,
    powerDelta: -16,
    deltaV: 0,
    reliabilityBonus: 9,
    tier: 3,
  },
  {
    id: 'com_uhf',
    category: 'comms',
    name: { ar: 'هوائي اتصال قياسي', en: 'Standard S-Band Dish' },
    desc: { ar: 'نقل موثوق داخل مدار القمر والمريخ.', en: 'Reliable telemetry across inner orbits.' },
    cost: 20,
    mass: 110,
    powerDelta: -5,
    deltaV: 0,
    reliabilityBonus: 3,
    tier: 1,
  },
  {
    id: 'com_laser',
    category: 'comms',
    name: { ar: 'رابط ليزر بصري DSN', en: 'Optical Laser DSN Link' },
    desc: { ar: 'يبث البيانات العلمية بسرعة مضاعفة.', en: 'High-bandwidth deep space laser telemetry.' },
    cost: 60,
    mass: 150,
    powerDelta: -9,
    deltaV: 0,
    reliabilityBonus: 7,
    tier: 2,
  },
];

export const SHIP_LIVERIES: ShipLivery[] = [
  {
    id: 'vanguard_cobalt',
    name: { ar: 'طليعة نوفا الكوبالت', en: 'NOVA Cobalt' },
    hullHex: '#e2e8f0',
    accentHex: '#06b6d4',
    thrusterHex: '#38bdf8',
    cost: 0,
  },
  {
    id: 'solar_gold',
    name: { ar: 'الريادة الذهبية', en: 'Solar Sovereign' },
    hullHex: '#f8fafc',
    accentHex: '#f59e0b',
    thrusterHex: '#fbbf24',
    cost: 0,
  },
  {
    id: 'crimson_phoenix',
    name: { ar: 'العنقاء القرمزية', en: 'Crimson Phoenix' },
    hullHex: '#1e293b',
    accentHex: '#ef4444',
    thrusterHex: '#fb7185',
    cost: 0,
  },
  {
    id: 'obsidian_stealth',
    name: { ar: 'الشبح الزمردي', en: 'Emerald Stealth' },
    hullHex: '#0f172a',
    accentHex: '#10b981',
    thrusterHex: '#34d399',
    cost: 0,
  },
];

export function computeShipMetrics(config: ShipConfig): ShipMetrics {
  const parts = [
    SHIP_PARTS.find((p) => p.id === config.engineId),
    SHIP_PARTS.find((p) => p.id === config.solarId),
    SHIP_PARTS.find((p) => p.id === config.hullId),
    SHIP_PARTS.find((p) => p.id === config.sensorId),
    SHIP_PARTS.find((p) => p.id === config.commsId),
  ].filter(Boolean) as ShipPartOption[];

  const mass = parts.reduce((acc, p) => acc + p.mass, 0);
  const totalCost = parts.reduce((acc, p) => acc + p.cost, 0);
  const powerGen = parts.filter((p) => p.powerDelta > 0).reduce((acc, p) => acc + p.powerDelta, 0);
  const powerUse = parts
    .filter((p) => p.powerDelta < 0)
    .reduce((acc, p) => acc + Math.abs(p.powerDelta), 0);
  const netPower = powerGen - powerUse;

  const engine = parts.find((p) => p.category === 'engine');
  const hull = parts.find((p) => p.category === 'hull');
  const sensor = parts.find((p) => p.category === 'sensor');

  const massPenalty = Math.max(0.76, 1 - (mass - 1800) / 8000);
  const deltaV = Math.round((engine?.deltaV || 3400) * massPenalty);
  const reliability = Math.min(
    99,
    62 + parts.reduce((acc, p) => acc + p.reliabilityBonus, 0) + (netPower >= 0 ? 5 : -10)
  );

  const engineLevel = engine?.tier ?? 1;
  const shieldLevel = hull?.tier ?? 1;
  const cannonLevel = sensor?.tier ?? 1;

  const mdlRiskScore = Math.max(5, Math.min(85, 102 - reliability + (netPower < 0 ? 18 : 0)));
  const thermalMargin = Math.min(98, 65 + shieldLevel * 10);
  const attitudePrecision = Math.min(99, 78 + cannonLevel * 6 + (engineLevel > 1 ? 4 : 0));

  return {
    mass,
    totalCost,
    powerGen,
    powerUse,
    netPower,
    deltaV,
    reliability,
    engineLevel,
    shieldLevel,
    cannonLevel,
    maxShield: 100 + (shieldLevel - 1) * 40,
    maxSpeed: 68 + (engineLevel - 1) * 18,
    mdlRiskScore,
    thermalMargin,
    attitudePrecision,
  };
}

// NASA CML (Concept Maturity Levels 1-4) & Mission Design Lab Framework
export const CML_LEVELS = [
  {
    level: 1,
    mdlPhase: { ar: 'CML 1: ساعات المكتب (Office Hours)', en: 'CML 1: Office Hours & Concept' },
    desc: {
      ar: 'تحديد الحاجة العلمية الأولية ومفهوم المهمة (ConOps).',
      en: 'Initial scientific question, mission concept & ConOps brainstorming.',
    },
  },
  {
    level: 2,
    mdlPhase: { ar: 'CML 2: دراسة الجدوى والمخاطر', en: 'CML 2: Concept Development & Risk' },
    desc: {
      ar: 'تقييم الجدوى الهندسية، ميزانية الطاقة، والتوازن المبدئي للكتلة.',
      en: 'Feasibility, power balance & initial spacecraft risk evaluation.',
    },
  },
  {
    level: 3,
    mdlPhase: { ar: 'CML 3: المفاضلات الهندسية (Trade Studies)', en: 'CML 3: Architecture Trade Studies' },
    desc: {
      ar: 'مقارنة المحركات، الأطوال الموجية للتلسكوب، ومسارات GMAT بين الكواكب.',
      en: 'Comparing propulsion, telescope wavelengths & GMAT interplanetary arcs.',
    },
  },
  {
    level: 4,
    mdlPhase: { ar: 'CML 4: التصميم التفصيلي (Point Design)', en: 'CML 4: Point Design & Flight Ops' },
    desc: {
      ar: 'جاهزية كاملة للإطلاق عبر القطاعات الأربعة: الإطلاق، الفضاء، المحطات الأرضية، والمستخدمون.',
      en: 'Full 4-segment verification: Launch, Space, Ground DSN & Science Users.',
    },
  },
];

// NASA Telescope Learning Game Catalog
export const TELESCOPE_OBJECTIVES: Array<{
  id: ScienceObjectiveId;
  name: Record<Language, string>;
  idealWavelength: WavelengthId;
  idealOptic: OpticSystemId;
  nasaAnalog: string;
  fact: Record<Language, string>;
}> = [
  {
    id: 'deep_galaxies',
    name: { ar: 'المجرات الأولى وتشكل النجوم', en: 'Primordial Galaxies & Star Formation' },
    idealWavelength: 'infrared',
    idealOptic: 'segmented_ir',
    nasaAnalog: 'James Webb Space Telescope (JWST)',
    fact: {
      ar: 'ينزاح ضوء المجرات البعيدة نحو الأشعة تحت الحمراء، لذا يتطلب مرايا سداسية مبردة بالدرع الشمسي مثل تلسكوب جيمس ويب.',
      en: 'Distant redshifted galaxies emit in Infrared, matching segmented cryogenic mirrors like NASA JWST.',
    },
  },
  {
    id: 'exoplanet_biosignatures',
    name: { ar: 'البحث عن بصمات الحياة بالكواكب', en: 'Exoplanet Atmospheres & Biosignatures' },
    idealWavelength: 'ultraviolet',
    idealOptic: 'coronagraph_uv',
    nasaAnalog: 'Habitable Worlds / Hubble UV-Optical',
    fact: {
      ar: 'الأشعة فوق البنفسجية والبصرية مع الكوروناغراف تحجب وهج النجم الأم لكشف الغلاف الجوي للكواكب.',
      en: 'UV/Optical spectroscopy with a starlight coronagraph reveals planetary atmospheres cleanly.',
    },
  },
  {
    id: 'high_energy_pulsars',
    name: { ar: 'الثقوب السوداء والنجوم النابضة', en: 'Black Holes & Accretion Pulsars' },
    idealWavelength: 'xray',
    idealOptic: 'wolter_xray',
    nasaAnalog: 'Chandra X-Ray Observatory',
    fact: {
      ar: 'أشعة X تخترق المرايا التقليدية، لذا تستخدم مرايا Wolter المائلة كما في مرصد تشاندرا.',
      en: 'High-energy X-rays require nested grazing-incidence Wolter mirrors like NASA Chandra.',
    },
  },
  {
    id: 'solar_corona',
    name: { ar: 'العواصف والهالة الشمسية', en: 'Solar Corona & Space Weather Flares' },
    idealWavelength: 'optical',
    idealOptic: 'wide_field_opt',
    nasaAnalog: 'Parker Solar Probe & SOHO',
    fact: {
      ar: 'رصد التوهجات الشمسية والطقس الفضائي يحمي رواد الفضاء وشبكات الكهرباء والأقمار الصناعية.',
      en: 'Monitoring solar flares safeguards astronauts, navigation, and deep-space comms.',
    },
  },
];

export const TELESCOPE_WAVELENGTHS: Array<{ id: WavelengthId; label: Record<Language, string> }> = [
  { id: 'infrared', label: { ar: 'الأشعة تحت الحمراء (IR)', en: 'Infrared (IR)' } },
  { id: 'optical', label: { ar: 'الضوء المرئي (Optical)', en: 'Visible Optical' } },
  { id: 'ultraviolet', label: { ar: 'الأشعة فوق البنفسجية (UV)', en: 'Ultraviolet (UV)' } },
  { id: 'xray', label: { ar: 'أشعة إكس عالية الطاقة (X-Ray)', en: 'High-Energy X-Ray' } },
];

export const TELESCOPE_OPTICS: Array<{ id: OpticSystemId; label: Record<Language, string> }> = [
  { id: 'segmented_ir', label: { ar: 'مرآة سداسية ذهبية (مبردة)', en: 'Segmented Gold Cryo-Mirror' } },
  { id: 'coronagraph_uv', label: { ar: 'نظام حجب نجمي (Coronagraph)', en: 'Starlight Coronagraph Array' } },
  { id: 'wolter_xray', label: { ar: 'مرايا انعكاس مائلة (Wolter)', en: 'Grazing-Incidence Wolter Optics' } },
  { id: 'wide_field_opt', label: { ar: 'عدسة ميدان واسع بدرع حراري', en: 'Wide-Field Thermal Shield Lens' } },
];

export const CUBESAT_PHASES = [
  { phase: 1, title: { ar: '1. مفهوم العملية (ConOps)', en: '1. Concept of Operations (ConOps)' } },
  { phase: 2, title: { ar: '2. تجميع هيكل 3U والحمولة', en: '2. 3U Bus & Payload Integration' } },
  { phase: 3, title: { ar: '3. الإطلاق ونشر الألواح (CSLI)', en: '3. Launch & Solar Deployment' } },
  { phase: 4, title: { ar: '4. تشغيل المنارة والبث (Beacon Ops)', en: '4. On-Orbit Beacon Telemetry' } },
];

export const PLANETS: PlanetData[] = [
  {
    id: 'luna',
    name: { ar: 'القمر (لونا)', en: 'Luna' },
    subtitle: { ar: 'محطة الانطلاق القمرية وفوهة شاكلتون', en: 'South Pole Outpost & Shackleton Basin' },
    description: {
      ar: 'قمر الأرض الصخري بجاذبية منخفضة وموقع مثالي لتجربة المركبة الجوالة وجمع عينات الهيليوم-3.',
      en: 'Earth’s airless rocky satellite with low gravity, deep polar craters, and Helium-3 deposits.',
    },
    discoveryFact: {
      ar: 'تحتفظ فوهات القطب الجنوبي القمري بجليد مائي نقي منذ مليارات السنين.',
      en: 'Permanently shadowed polar craters preserve ancient water-ice reservoirs.',
    },
    resourceName: { ar: 'جليد القطب القمري', en: 'Lunar Polar Regolith' },
    position: [0, 0, -170],
    radius: 22,
    orbitDistance: 56,
    surfaceKind: 'terran',
    primaryColor: '#cbd5e1',
    atmosphereColor: '#94a3b8',
    terrainColor: '#64748b',
    terrainAccent: '#94a3b8',
    skyColor: '#040710',
    gravity: 1.62,
    moonCount: 0,
    sampleTarget: 3,
    rewardCredits: 180,
    rewardXp: 120,
    craters: [
      { id: 'luna_c1', name: { ar: 'فوهة شاكلتون', en: 'Shackleton Rim' }, x: 34, z: -26, radius: 14 },
      { id: 'luna_c2', name: { ar: 'حوض تايكو الصغير', en: 'Tycho Basin' }, x: -40, z: 24, radius: 16 },
    ],
    scienceSites: [
      { id: 'luna_s1', name: { ar: 'مجس الطيف القطبي', en: 'Polar Ice Spectrometer' }, x: -24, z: -38, dataYieldMb: 45 },
      { id: 'luna_s2', name: { ar: 'مرصد الإشارة المداري', en: 'Relay Beacon Alpha' }, x: 42, z: 32, dataYieldMb: 50 },
    ],
  },
  {
    id: 'mars',
    name: { ar: 'المريخ (إليسيوم)', en: 'Mars' },
    subtitle: { ar: 'الكوكب الأحمر ومصدر إشارة 2089', en: 'Elysium Mons & 2089 Signal Origin' },
    description: {
      ar: 'أرض الكثبان الحديدية الحمراء والوديان القديمة حيث تم رصد نبضة 2089 الغامضة لأول مرة.',
      en: 'Rust-iron canyons and dust plains radiating the mysterious 2089 harmonic signal.',
    },
    discoveryFact: {
      ar: 'ينبعث تحت سهول إليسيوم تردد منظم يشير إلى مسلّة قديمة مدفونة منذ عصور.',
      en: 'Sub-surface resonance beneath Elysium Plains originates from an ancient crystalline monolith.',
    },
    resourceName: { ar: 'بلورات الهيماتيت المريخية', en: 'Martian Hematite Core' },
    position: [260, 26, -340],
    radius: 28,
    orbitDistance: 66,
    surfaceKind: 'desert',
    primaryColor: '#ea580c',
    atmosphereColor: '#fb923c',
    terrainColor: '#9a3412',
    terrainAccent: '#ea580c',
    skyColor: '#26110a',
    gravity: 3.72,
    moonCount: 2,
    sampleTarget: 4,
    rewardCredits: 300,
    rewardXp: 200,
    hasMonolith: true,
    craters: [
      { id: 'mars_c1', name: { ar: 'فوهة جيزيرو', en: 'Jezero Delta' }, x: 38, z: -20, radius: 15 },
      { id: 'mars_c2', name: { ar: 'منخفض هيلاس', en: 'Hellas Rim' }, x: -36, z: 30, radius: 17 },
    ],
    scienceSites: [
      { id: 'mars_s1', name: { ar: 'حفّار المياه الجوفية', en: 'Aquifer Core Drill' }, x: -32, z: -34, dataYieldMb: 60 },
      { id: 'mars_s2', name: { ar: 'مصفوفة رصد الغلاف الجوي', en: 'Barometric Station' }, x: 22, z: 42, dataYieldMb: 55 },
    ],
  },
  {
    id: 'aurora',
    name: { ar: 'أورورا برايم', en: 'Aurora Prime' },
    subtitle: { ar: 'أرخبيل الشفق المائي والزمردي', en: 'Emerald Archipelagos & Auroras' },
    description: {
      ar: 'كوكب شبيه بالأرض تغطيه محيطات كريستالية ومجالات مغناطيسية تولد شفقاً أزرق ساطعاً.',
      en: 'An oxygen-rich exoplanet with sapphire seas and luminous magnetosphere ribbons.',
    },
    discoveryFact: {
      ar: 'تشحن حقوله المغناطيسية أجنحة السفن الشمسية بكفاءة مضاعفة.',
      en: 'Auroral ion currents boost orbital solar collector efficiency by 40%.',
    },
    resourceName: { ar: 'كوارتز الأثير المائي', en: 'Hydro-Aether Quartz' },
    position: [-290, -20, -260],
    radius: 27,
    orbitDistance: 64,
    surfaceKind: 'emerald_nebula',
    primaryColor: '#10b981',
    atmosphereColor: '#34d399',
    terrainColor: '#065f46',
    terrainAccent: '#10b981',
    skyColor: '#041a18',
    gravity: 7.4,
    moonCount: 1,
    sampleTarget: 3,
    rewardCredits: 260,
    rewardXp: 180,
    craters: [
      { id: 'aur_c1', name: { ar: 'فوهة اللازورد', en: 'Azure Caldera' }, x: 30, z: 32, radius: 14 },
      { id: 'aur_c2', name: { ar: 'سهل الشفق', en: 'Aurora Shelf' }, x: -42, z: -18, radius: 15 },
    ],
    scienceSites: [
      { id: 'aur_s1', name: { ar: 'محطة الأحياء المضيئة', en: 'Bio-Luminescence Lab' }, x: 28, z: -36, dataYieldMb: 65 },
    ],
  },
  {
    id: 'solaris',
    name: { ar: 'سولاريس البركاني', en: 'Solaris Ignis' },
    subtitle: { ar: 'عالم الحمم والطاقة الشمسية', en: 'Volcanic Forge & Solar Flares' },
    description: {
      ar: 'كوكب منصهر تقترب منه التوهجات الشمسية العنيفة، غني بالتيتانيوم الحراري والسبائك النادرة.',
      en: 'A molten basalt world bathed in solar flares and rich in pyro-titanium veins.',
    },
    discoveryFact: {
      ar: 'الوجود قرب سولاريس يزيد احتمالية العواصف الشمسية التي ترفع السرعة وتستنزف الدروع.',
      en: 'Close solar proximity triggers high-velocity flare storms that challenge hull shields.',
    },
    resourceName: { ar: 'سبائك البلازما الحرارية', en: 'Pyro-Titanium Ore' },
    position: [430, 48, -540],
    radius: 30,
    orbitDistance: 72,
    surfaceKind: 'volcanic',
    primaryColor: '#f97316',
    atmosphereColor: '#fbbf24',
    terrainColor: '#292524',
    terrainAccent: '#ea580c',
    skyColor: '#220b04',
    gravity: 9.1,
    moonCount: 0,
    sampleTarget: 4,
    rewardCredits: 380,
    rewardXp: 250,
    craters: [
      { id: 'sol_c1', name: { ar: 'فوهة الصهارة الكبرى', en: 'Magma Caldera' }, x: -34, z: -28, radius: 16 },
      { id: 'sol_c2', name: { ar: 'صدع الكبريت', en: 'Sulfur Rift' }, x: 40, z: 24, radius: 13 },
    ],
    scienceSites: [
      { id: 'sol_s1', name: { ar: 'مسبار الحرارة الجوفية', en: 'Thermal Core Probe' }, x: 18, z: -42, dataYieldMb: 75 },
    ],
  },
  {
    id: 'aetheris',
    name: { ar: 'زحل الكريستالي', en: 'Cryo Aetheris' },
    subtitle: { ar: 'عملاق جليدي بحلقات بلورية', en: 'Ringed Ice Giant' },
    description: {
      ar: 'عالم جليدي فيروزي محاط بحلقات كوارتز متجمدة تنعكس عليها أضواء المجرة.',
      en: 'A sapphire frozen world encircled by shimmering crystalline orbital rings.',
    },
    discoveryFact: {
      ar: 'أقماره الجليدية تخفي محيطات دافئة تحت قشرة سميكة من الجليد النقي.',
      en: 'Its ringed frozen surface hides conductive crystal aquifers below.',
    },
    resourceName: { ar: 'جليد الكوارتز الكمي', en: 'Quantum Cryo-Shards' },
    position: [-410, -32, -590],
    radius: 34,
    orbitDistance: 84,
    surfaceKind: 'cryo_giant',
    primaryColor: '#60a5fa',
    atmosphereColor: '#bae6fd',
    terrainColor: '#1e3a8a',
    terrainAccent: '#60a5fa',
    skyColor: '#071326',
    gravity: 6.4,
    hasRings: true,
    ringColor: '#bae6fd',
    moonCount: 2,
    sampleTarget: 4,
    rewardCredits: 420,
    rewardXp: 290,
    craters: [
      { id: 'aet_c1', name: { ar: 'فوهة الجليد الأزرق', en: 'Glacier Bowl' }, x: 35, z: -30, radius: 16 },
      { id: 'aet_c2', name: { ar: 'نبع الكريستال', en: 'Cryo Vent' }, x: -30, z: 36, radius: 14 },
    ],
    scienceSites: [
      { id: 'aet_s1', name: { ar: 'ماسح الحلقات الجليدية', en: 'Ring Acoustic Scanner' }, x: -40, z: -22, dataYieldMb: 80 },
    ],
  },
  {
    id: 'obsidian',
    name: { ar: 'الثقب السحيق', en: 'Obsidian Singularity' },
    subtitle: { ar: 'حافة القطاع ونبضة 2089 النهائية', en: 'Outer Sector Dark-Matter Core' },
    description: {
      ar: 'جرم نادر في أقاصي القطاع تحيط به هالة الجاذبية البنفسجية ومسلّة البث الكوني.',
      en: 'An outer-sector dark-matter world wrapped in an accretion halo and signal monoliths.',
    },
    discoveryFact: {
      ar: 'تلتف العواصف الأيونية حول أفقه لكنه يضاعف طاقة المفاعل عند اختراقها بنجاح.',
      en: 'Ion storms crackle across its horizon while the Monolith amplifies deep-space transmissions.',
    },
    resourceName: { ar: 'نواة المادة المظلمة', en: 'Singularity Core' },
    position: [0, 82, -880],
    radius: 32,
    orbitDistance: 82,
    surfaceKind: 'obsidian',
    primaryColor: '#a855f7',
    atmosphereColor: '#c084fc',
    terrainColor: '#1e1b4b',
    terrainAccent: '#a855f7',
    skyColor: '#0c061c',
    gravity: 5.2,
    hasRings: true,
    ringColor: '#f59e0b',
    moonCount: 1,
    sampleTarget: 4,
    rewardCredits: 600,
    rewardXp: 420,
    hasMonolith: true,
    craters: [
      { id: 'obs_c1', name: { ar: 'أفق الحدث', en: 'Event Sink' }, x: -36, z: -24, radius: 16 },
      { id: 'obs_c2', name: { ar: 'وادي الكوارك', en: 'Quark Hollow' }, x: 38, z: 28, radius: 15 },
    ],
    scienceSites: [
      { id: 'obs_s1', name: { ar: 'محلل الإشارة النهائية', en: 'Singularity Decoder' }, x: 0, z: -48, dataYieldMb: 110 },
    ],
  },
];

export const INITIAL_CREW: CrewMember[] = [
  {
    id: 'vance',
    name: { ar: 'د. إيلينا فانس', en: 'Dr. Elena Vance' },
    role: { ar: 'كبيرة علماء الأحياء الفلكية', en: 'Lead Astrobiologist' },
    assignment: 'Science',
    morale: 92,
    fatigue: 12,
  },
  {
    id: 'chen',
    name: { ar: 'ماركوس تشين', en: 'Marcus Chen' },
    role: { ar: 'كبير مهندسي الدفع والطاقة', en: 'Chief Propulsion Engineer' },
    assignment: 'Engineering',
    morale: 88,
    fatigue: 18,
  },
  {
    id: 'sato',
    name: { ar: 'الملازم آريا ساتو', en: 'Lt. Aria Sato' },
    role: { ar: 'ضابطة الاتصالات والملاحة', en: 'DSN Comms & Flight Officer' },
    assignment: 'Comms',
    morale: 94,
    fatigue: 10,
  },
];

export const SHUTTLE_ROOM_DEFS: Array<{
  id: ShuttleRoomId;
  code: string;
  name: Record<Language, string>;
  focusStat: Record<Language, string>;
}> = [
  {
    id: 'helm',
    code: 'RM-01',
    name: { ar: 'قمرة القيادة الأمامية', en: 'Forward Flight Deck' },
    focusStat: { ar: 'سرعة الطيران وكفاءة المحرك', en: 'Flight Speed & Thruster Efficiency' },
  },
  {
    id: 'nav',
    code: 'RM-02',
    name: { ar: 'غرفة الملاحة GMAT', en: 'GMAT Trajectory Room' },
    focusStat: { ar: 'دقة الاكتشاف العلمي والملاحة', en: 'Science Discovery & Trajectory Precision' },
  },
  {
    id: 'science_lab',
    code: 'RM-03',
    name: { ar: 'مختبر التلسكوب و CubeSat', en: 'Telescope & CubeSat Lab' },
    focusStat: { ar: 'معدل الاكتشاف والبيانات العلمية', en: 'Science Discovery Rate & Data Yield' },
  },
  {
    id: 'bio_bay',
    code: 'RM-04',
    name: { ar: 'غرفة الزراعة المائية', en: 'Hydroponics Bio-Dome' },
    focusStat: { ar: 'دعم الحياة O2 والأبحاث الحيوية', en: 'O2 Regen & Bio-Science Discovery' },
  },
  {
    id: 'lounge',
    code: 'RM-05',
    name: { ar: 'الاستراحة والقهوة والنوم', en: 'Crew Galley & Quarters' },
    focusStat: { ar: 'معنويات الطاقم واستعادة الطاقة', en: 'Crew Stamina & Recovery Rate' },
  },
  {
    id: 'med_bay',
    code: 'RM-06',
    name: { ar: 'العيادة الطبية والإشعاع', en: 'Medical & Radiation Bay' },
    focusStat: { ar: 'مقاومة الإشعاع واستعادة O2', en: 'Medical Care & Radiation Mitigation' },
  },
  {
    id: 'engineering',
    code: 'RM-07',
    name: { ar: 'غرفة المفاعل والهندسة MDL', en: 'MDL & Fusion Reactor' },
    focusStat: { ar: 'سرعة الإصلاح وشحن الدروع والطاقة', en: 'Repair Speed & Shield/Power Regen' },
  },
  {
    id: 'cargo_bay',
    code: 'RM-08',
    name: { ar: 'عنبر الحمولة والروفر 6×6', en: 'Cargo Bay & 6x6 Rover' },
    focusStat: { ar: 'إصلاح الهيكل وصيانة الروفر', en: 'Hull Repair Speed & Rover Tuning' },
  },
  {
    id: 'comms_desk',
    code: 'RM-09',
    name: { ar: 'غرفة اتصالات DSN', en: 'Deep Space Network DSN' },
    focusStat: { ar: 'سرعة البث العلمي للأرض', en: 'DSN Transmission & Signal Gain' },
  },
  {
    id: 'airlock',
    code: 'RM-10',
    name: { ar: 'بوابة الهبوط الكوكبي', en: 'Planetary EVA Airlock' },
    focusStat: { ar: 'كفاءة الهبوط والصيانة الميدانية', en: 'EVA Readiness & Field Repair' },
  },
];

export const INITIAL_SPECIALISTS: ShuttleSpecialist[] = [
  {
    id: 'ryan',
    name: { ar: 'الكابتن رايان ميلر', en: 'Capt. Ryan Miller' },
    role: { ar: 'كبير طياري المكوك', en: 'Chief Shuttle Pilot' },
    specialty: 'flight',
    skillRating: 94,
    idealRooms: ['helm', 'airlock'],
    assignedRoomId: 'helm',
    trait: { ar: '+14% كفاءة الطيران والمناورة', en: '+14% Flight Speed & Handling' },
  },
  {
    id: 'nadia',
    name: { ar: 'د. نادية كريم', en: 'Dr. Nadia Karim' },
    role: { ar: 'محللة مسارات GMAT', en: 'GMAT Trajectory Analyst' },
    specialty: 'science',
    skillRating: 91,
    idealRooms: ['nav', 'science_lab'],
    assignedRoomId: 'nav',
    trait: { ar: '+15% دقة الاكتشاف العلمي', en: '+15% Science Discovery Rate' },
  },
  {
    id: 'elena',
    name: { ar: 'د. إيلينا فانس', en: 'Dr. Elena Vance' },
    role: { ar: 'عالمة الفيزياء الفلكية', en: 'Lead Astrophysicist' },
    specialty: 'science',
    skillRating: 96,
    idealRooms: ['science_lab', 'nav'],
    assignedRoomId: 'science_lab',
    trait: { ar: '+22% سرعة الاكتشاف العلمي', en: '+22% Science Discovery Rate' },
  },
  {
    id: 'omar',
    name: { ar: 'د. عمر فاروق', en: 'Dr. Omar Farouk' },
    role: { ar: 'خبير النباتات والأكسجين', en: 'Hydroponics Botanist' },
    specialty: 'medical',
    skillRating: 89,
    idealRooms: ['bio_bay', 'med_bay'],
    assignedRoomId: 'bio_bay',
    trait: { ar: '+18% تجدد O2 وأبحاث حيوية', en: '+18% O2 Regen & Bio Science' },
  },
  {
    id: 'maya',
    name: { ar: 'مايا لين', en: 'Maya Lin' },
    role: { ar: 'مسؤولة الإعاشة والطاقم', en: 'Habitation Officer' },
    specialty: 'medical',
    skillRating: 86,
    idealRooms: ['lounge', 'bio_bay'],
    assignedRoomId: 'lounge',
    trait: { ar: '+14% تعافي الطاقم والطاقة', en: '+14% Crew & Stamina Recovery' },
  },
  {
    id: 'sophia',
    name: { ar: 'د. صوفيا باتيل', en: 'Dr. Sophia Patel' },
    role: { ar: 'طبيبة الإشعاع الفضائي', en: 'Flight & Radiation Surgeon' },
    specialty: 'medical',
    skillRating: 93,
    idealRooms: ['med_bay', 'bio_bay'],
    assignedRoomId: 'med_bay',
    trait: { ar: '+20% حماية حيوية وعلاجية', en: '+20% Life Support & Med Recovery' },
  },
  {
    id: 'marcus',
    name: { ar: 'ماركوس تشين', en: 'Marcus Chen' },
    role: { ar: 'مهندس الدفع والمفاعل', en: 'NASA MDL Engineer' },
    specialty: 'engineering',
    skillRating: 95,
    idealRooms: ['engineering', 'cargo_bay'],
    assignedRoomId: 'engineering',
    trait: { ar: '+24% سرعة الإصلاح وشحن الدروع', en: '+24% Repair Speed & Shield Regen' },
  },
  {
    id: 'devon',
    name: { ar: 'الرقيب ديفون بروكس', en: 'Sgt. Devon Brooks' },
    role: { ar: 'متخصص الروفر والحمولة', en: 'Payload & Rover Chief' },
    specialty: 'engineering',
    skillRating: 90,
    idealRooms: ['cargo_bay', 'engineering'],
    assignedRoomId: 'cargo_bay',
    trait: { ar: '+18% سرعة الإصلاح وصيانة الروفر', en: '+18% Repair Speed & Hull Maintenance' },
  },
  {
    id: 'aria',
    name: { ar: 'الملازم آريا ساتو', en: 'Lt. Aria Sato' },
    role: { ar: 'ضابطة البث الأرضي', en: 'DSN Comms Officer' },
    specialty: 'comms',
    skillRating: 92,
    idealRooms: ['comms_desk', 'nav'],
    assignedRoomId: 'comms_desk',
    trait: { ar: '+20% سرعة البث والبيانات', en: '+20% DSN Uplink & Telemetry Rate' },
  },
  {
    id: 'leo',
    name: { ar: 'القائد ليو فانس', en: 'Cmdr. Leo Vance' },
    role: { ar: 'ضابط بوابة الخروج EVA', en: 'EVA Airlock Officer' },
    specialty: 'flight',
    skillRating: 88,
    idealRooms: ['airlock', 'cargo_bay'],
    assignedRoomId: 'airlock',
    trait: { ar: '+12% إصلاح ميداني وكفاءة هبوط', en: '+12% Field Repair & EVA Readiness' },
  },
];

export function computePersonnelEffects(specialists: ShuttleSpecialist[]): PersonnelEffects {
  let repairBonus = 0;
  let scienceBonus = 0;
  let lifeSupportBonus = 0;
  let commsBonus = 0;
  let flightBonus = 0;
  let synergyCount = 0;

  for (const sp of specialists) {
    const skillFactor = sp.skillRating / 100;
    const isIdeal = sp.idealRooms.includes(sp.assignedRoomId);
    if (isIdeal) synergyCount += 1;
    const synergyMult = isIdeal ? 1.5 : 0.72;
    const specMatchEngineering = sp.specialty === 'engineering' ? 1.35 : 0.65;
    const specMatchScience = sp.specialty === 'science' ? 1.35 : 0.65;
    const specMatchMedical = sp.specialty === 'medical' ? 1.35 : 0.65;
    const specMatchComms = sp.specialty === 'comms' ? 1.35 : 0.7;
    const specMatchFlight = sp.specialty === 'flight' ? 1.35 : 0.7;

    const r = sp.assignedRoomId;
    if (r === 'engineering' || r === 'cargo_bay' || r === 'airlock') {
      const roomWeight = r === 'engineering' ? 0.14 : r === 'cargo_bay' ? 0.11 : 0.06;
      repairBonus += roomWeight * skillFactor * synergyMult * specMatchEngineering;
    }
    if (r === 'science_lab' || r === 'nav' || r === 'bio_bay') {
      const roomWeight = r === 'science_lab' ? 0.16 : r === 'nav' ? 0.12 : 0.07;
      scienceBonus += roomWeight * skillFactor * synergyMult * specMatchScience;
    }
    if (r === 'bio_bay' || r === 'med_bay' || r === 'lounge') {
      const roomWeight = r === 'med_bay' ? 0.14 : r === 'bio_bay' ? 0.12 : 0.09;
      lifeSupportBonus += roomWeight * skillFactor * synergyMult * specMatchMedical;
    }
    if (r === 'comms_desk' || r === 'nav') {
      const roomWeight = r === 'comms_desk' ? 0.18 : 0.07;
      commsBonus += roomWeight * skillFactor * synergyMult * specMatchComms;
    }
    if (r === 'helm' || r === 'airlock') {
      const roomWeight = r === 'helm' ? 0.14 : 0.07;
      flightBonus += roomWeight * skillFactor * synergyMult * specMatchFlight;
    }
  }

  return {
    repairSpeedMult: Number((0.78 + repairBonus).toFixed(2)),
    scienceRateMult: Number((0.76 + scienceBonus).toFixed(2)),
    lifeSupportRateMult: Number((0.8 + lifeSupportBonus).toFixed(2)),
    commsRateMult: Number((0.82 + commsBonus).toFixed(2)),
    flightEfficiencyMult: Number((0.84 + flightBonus).toFixed(2)),
    synergyCount,
  };
}

export const STORY_CHAPTERS = [
  {
    chapter: 1,
    title: { ar: 'الفصل 1: تأسيس المهمة (CML 1-4 و MDL)', en: 'Ch 1: Mission Design Lab & CML 1-4' },
    summary: { ar: 'صمّم التلسكوب في مختبر المركبة وراجع جاهزية القطاعات الأربعة من جسر القيادة.', en: 'Calibrate your telescope lab and verify the 4 mission segments from the bridge.' },
  },
  {
    chapter: 2,
    title: { ar: 'الفصل 2: مسارات GMAT والطيران الأول', en: 'Ch 2: GMAT Trajectory & Lunar Flight' },
    summary: { ar: 'اعبر مسار GMAT المداري، حلّق إلى القمر (لونا)، وجرّب المركبة الجوالة 6×6.', en: 'Inspect 3D GMAT transfer arcs, pilot to Luna, and drive the 6x6 rover.' },
  },
  {
    chapter: 3,
    title: { ar: 'الفصل 3: تحدي طقس الفضاء والأقمار المكعبة', en: 'Ch 3: Space Weather & CubeSat 101' },
    summary: { ar: 'انشر قمر CubeSat الصناعي وتحدَّ التوهجات الشمسية والعواصف الأيونية.', en: 'Deploy your 3U CubeSat and navigate flares, squalls, and ion storms.' },
  },
  {
    chapter: 4,
    title: { ar: 'الفصل 4: أسرار المريخ وإشارة 2089', en: 'Ch 4: Elysium Signal 2089' },
    summary: { ar: 'افحص المسلّة المتوهجة على المريخ أو الثقب السحيق واجمع العينات.', en: 'Inspect the 2089 monolith on Mars or Obsidian Singularity.' },
  },
  {
    chapter: 5,
    title: { ar: 'الفصل 5: البث العلمي لقطاع المستخدمين (DSN)', en: 'Ch 5: Ground & Science User Uplink' },
    summary: { ar: 'أرسل البيانات عبر شبكة الفضاء العميق للأرض واختم المهمة.', en: 'Transmit data to Earth DSN Ground stations and publish your findings.' },
  },
];
