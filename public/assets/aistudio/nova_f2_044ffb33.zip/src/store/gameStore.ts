import { create } from 'zustand';
import { spaceAudio } from '../audio/spaceAudio';
import {
  generateSkyChatReply,
  getDisplayCommander,
  getEnglishCommander,
  skyEventText,
  skyGreeting,
} from '../data/i18n';
import {
  CUBESAT_PHASES,
  INITIAL_CREW,
  INITIAL_SPECIALISTS,
  PLANETS,
  SHIP_LIVERIES,
  TELESCOPE_OBJECTIVES,
  computePersonnelEffects,
  computeShipMetrics,
} from '../data/novaData';
import { SURVIVAL_MISSIONS } from '../data/nasaSurvivalData';
import { BASELINE_LEADERBOARD, type SavedArchitectRun } from '../data/missionArchitectData';
import type {
  ActiveChoice,
  AstronautBioState,
  CameraMode,
  CharacterConfig,
  CrewMember,
  DifficultyLevel,
  EmergencyEvent,
  GameScreen,
  GameSettings,
  InteriorStationId,
  InteriorTelemetrySnapshot,
  Language,
  MissionOutcome,
  PersonnelEffects,
  PlanetId,
  QualityPreset,
  ResourcesState,
  SceneEnv,
  ShipConfig,
  ShipLiveryId,
  ShipMetrics,
  ShuttleRoomId,
  ShuttleSpecialist,
  SkyMessage,
  SkyMood,
  SpaceTelemetrySnapshot,
  SpaceWeather,
  SpecialistId,
  SurfaceBuildingKind,
  SurfaceBuildingRecord,
  SurfaceTelemetrySnapshot,
  TabletMissionPlan,
  TelescopeDesignState,
} from '../types/game';

export interface EngineActionsBridge {
  enterInteriorBridge: () => void;
  walkToInteriorStation: (stationId: InteriorStationId) => void;
  launchToSpace: (fromPlanetId?: PlanetId) => void;
  landOnPlanet: (planetId: PlanetId) => void;
  setTargetPlanet: (planetId: PlanetId, autopilot: boolean) => void;
  setAutopilot: (active: boolean) => void;
  triggerBarrelRoll: () => void;
  fireOrScan: () => void;
  toggleRover: () => void;
  cycleWeather: () => void;
  setWeather: (weather: SpaceWeather) => void;
  setCameraMode: (mode: CameraMode) => void;
  resetSpaceShipNearHome: () => void;
  setMissionVizState: (timeline: number, targetPlanetId: PlanetId) => void;
  setMouseLocked: (locked: boolean) => void;
  toggleMouseLock: () => void;
  applySettings: (settings: GameSettings) => void;
  buildSurfaceStructure: (kind: SurfaceBuildingKind) => SurfaceBuildingRecord | null;
}

let engineBridge: EngineActionsBridge | null = null;
export function registerEngineBridge(bridge: EngineActionsBridge | null) {
  engineBridge = bridge;
}

export interface VirtualInputState {
  thrust: number;
  yaw: number;
  pitch: number;
  boost: boolean;
}

const SAVE_KEY = 'nova_beyond_unified_save_v2';
const LANG_KEY = 'nova_lang_v1';
const AUDIO_PREFS_KEY = 'nova_audio_prefs_v1';
const SETTINGS_KEY = 'nova_game_settings_v1';

const DEFAULT_SETTINGS: GameSettings = {
  qualityPreset: 'high',
  resolutionScale: 1,
  gameplaySpeed: 1.35,
  fov: 68,
  mouseSensitivity: 1.25,
  invertY: false,
  bloomEnabled: true,
  masterVolume: 0.85,
};

function readInitialSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    return {
      qualityPreset:
        parsed.qualityPreset === 'low' ||
        parsed.qualityPreset === 'medium' ||
        parsed.qualityPreset === 'high' ||
        parsed.qualityPreset === 'ultra'
          ? parsed.qualityPreset
          : DEFAULT_SETTINGS.qualityPreset,
      resolutionScale:
        typeof parsed.resolutionScale === 'number'
          ? Math.max(0.65, Math.min(2, parsed.resolutionScale))
          : DEFAULT_SETTINGS.resolutionScale,
      gameplaySpeed:
        typeof parsed.gameplaySpeed === 'number'
          ? Math.max(0.85, Math.min(2, parsed.gameplaySpeed))
          : DEFAULT_SETTINGS.gameplaySpeed,
      fov:
        typeof parsed.fov === 'number'
          ? Math.max(55, Math.min(90, parsed.fov))
          : DEFAULT_SETTINGS.fov,
      mouseSensitivity:
        typeof parsed.mouseSensitivity === 'number'
          ? Math.max(0.5, Math.min(2.5, parsed.mouseSensitivity))
          : DEFAULT_SETTINGS.mouseSensitivity,
      invertY: Boolean(parsed.invertY),
      bloomEnabled:
        typeof parsed.bloomEnabled === 'boolean' ? parsed.bloomEnabled : DEFAULT_SETTINGS.bloomEnabled,
      masterVolume:
        typeof parsed.masterVolume === 'number'
          ? Math.max(0, Math.min(1, parsed.masterVolume))
          : DEFAULT_SETTINGS.masterVolume,
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function persistSettings(settings: GameSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

interface SavedAudioPrefs {
  audioMuted: boolean;
  ambientHumEnabled: boolean;
  roverAudioEnabled: boolean;
  speechEnabled: boolean;
}

function readInitialAudioPrefs(): SavedAudioPrefs {
  const defaults: SavedAudioPrefs = {
    audioMuted: false,
    ambientHumEnabled: true,
    roverAudioEnabled: true,
    speechEnabled: true,
  };
  try {
    const raw = localStorage.getItem(AUDIO_PREFS_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<SavedAudioPrefs>;
    return {
      audioMuted: Boolean(parsed.audioMuted),
      ambientHumEnabled:
        typeof parsed.ambientHumEnabled === 'boolean' ? parsed.ambientHumEnabled : true,
      roverAudioEnabled:
        typeof parsed.roverAudioEnabled === 'boolean' ? parsed.roverAudioEnabled : true,
      speechEnabled:
        typeof parsed.speechEnabled === 'boolean' ? parsed.speechEnabled : true,
    };
  } catch {
    return defaults;
  }
}

function persistAudioPrefs(prefs: SavedAudioPrefs) {
  try {
    localStorage.setItem(AUDIO_PREFS_KEY, JSON.stringify(prefs));
  } catch {
    // ignore
  }
}

const DEFAULT_CHARACTER: CharacterConfig = {
  name: '',
  gender: 'male',
  specialization: 'Flight Commander',
  suitModel: 'Vanguard EVA',
  primaryColor: '#e2e6ec',
  visorColor: '#0d1520',
  helmetEquipped: false,
};

const DEFAULT_SHIP: ShipConfig = {
  engineId: 'eng_vasimir',
  solarId: 'sol_rtg',
  hullId: 'hull_aegis',
  sensorId: 'sen_spectro',
  commsId: 'com_laser',
  liveryId: 'vanguard_cobalt',
};

const DEFAULT_INTERIOR_TELEMETRY: InteriorTelemetrySnapshot = {
  playerX: 0,
  playerZ: 2,
  nearStation: null,
};

const DEFAULT_SPACE_TELEMETRY: SpaceTelemetrySnapshot = {
  speed: 28,
  maxSpeed: 86,
  boosting: false,
  shield: 140,
  maxShield: 140,
  shipX: 0,
  shipY: 12,
  shipZ: 48,
  shipYaw: 0,
  shipPitchDeg: 0,
  shipRollDeg: 0,
  shipHeadingDeg: 0,
  accelG: 0.4,
  altitudeKm: 412,
  autopilotActive: false,
  targetPlanetId: 'luna',
  targetDistance: 218,
  nearbyPlanetId: null,
  nearbyPlanetDistance: null,
  radarBlips: [],
  cannonCooldown: 0,
  barrelRollCooldown: 0,
  weather: 'clear',
  weatherSpeedMultiplier: 1,
  weatherShieldDelta: 2.5,
  radiationSievert: 0.12,
  dustDensityPct: 4,
  hazardLevel: 'NOMINAL',
  weatherCountdown: 26,
};

const DEFAULT_SURFACE_TELEMETRY: SurfaceTelemetrySnapshot = {
  playerX: 0,
  playerZ: 14,
  roverX: 10,
  roverZ: 8,
  speedKmh: 0,
  headingDeg: 0,
  inRover: false,
  nearShipPad: false,
  hostileAlienDist: null,
  nearInteractable: null,
};

const DEFAULT_ASTRONAUT_BIO: AstronautBioState = {
  heartRateBpm: 72,
  suitPressureKpa: 29.6,
  co2MmHg: 1.4,
  suitTempC: 21.5,
  lcvgCoolingPct: 50,
  preBreatheDone: false,
  tetherLocked: true,
  stressLevel: 'CALM',
  evaRepairsCompleted: 0,
};

function makeInitialResources(diff: DifficultyLevel): ResourcesState {
  const budgetMap: Record<DifficultyLevel, number> = {
    Cadet: 520,
    Commander: 400,
    Veteran: 310,
  };
  const metrics = computeShipMetrics(DEFAULT_SHIP);
  return {
    budget: budgetMap[diff],
    mass: metrics.mass,
    powerGeneration: metrics.powerGen,
    powerConsumption: metrics.powerUse,
    battery: 96,
    dataStorage: 0,
    maxStorage: 450,
    dataCollected: 0,
    dataTransmitted: 0,
    commsStation: 'Goldstone',
    commsSignal: 94,
    solTime: 1,
    suitO2: 100,
    suitHealth: 100,
    suitCoolant: 100,
    credits: 320,
  };
}

let msgCounter = 1;

export interface GameStoreState {
  lang: Language;
  screen: GameScreen;
  sceneEnv: SceneEnv;
  difficulty: DifficultyLevel;
  chapter: number;
  character: CharacterConfig;
  shipConfig: ShipConfig;
  shipMetrics: ShipMetrics;
  resources: ResourcesState;
  crew: CrewMember[];
  specialists: ShuttleSpecialist[];
  personnelEffects: PersonnelEffects;
  missionPlan: TabletMissionPlan;

  activePlanet: PlanetId;
  discoveredPlanets: PlanetId[];
  discoveredCraterIds: string[];
  completedScienceSiteIds: string[];
  collectedSampleIds: string[];
  scannedCreatureIds: string[];
  surfaceBuildings: SurfaceBuildingRecord[];
  outpostMenuOpen: boolean;
  monolithInspected: boolean;
  pilotingRover: boolean;
  cameraMode: CameraMode;

  ringsPassed: number;
  asteroidsMined: number;
  barrelRolls: number;
  weather: SpaceWeather;

  interiorTelemetry: InteriorTelemetrySnapshot;
  spaceTelemetry: SpaceTelemetrySnapshot;
  surfaceTelemetry: SurfaceTelemetrySnapshot;
  virtualInput: VirtualInputState;
  touchPadOpen: boolean;

  skyMessages: SkyMessage[];
  skyMood: SkyMood;
  skyOpen: boolean;
  tabletOpen: boolean;
  tabletTab: 'overview' | 'planets' | 'builder' | 'comms' | 'crew';
  mapOpen: boolean;
  guideOpen: boolean;
  dashboardOpen: boolean;
  dashboardTab: 'overview' | 'personnel';
  mode2dOpen: boolean;
  mode2dTab: 'dashboard2d' | 'space2d' | 'planet2d' | 'shuttle2d';
  mouseLocked: boolean;
  storyIntroOpen: boolean;
  architectOpen: boolean;
  architectRuns: SavedArchitectRun[];

  hullIntegrity: number;
  survivalFailures: number;
  survivalScore: number;
  survivalStreak: number;
  completedSurvivalIds: string[];
  failedSurvivalIds: string[];
  activeSurvivalId: string | null;
  astronautBio: AstronautBioState;

  cmlLevel: 1 | 2 | 3 | 4;
  telescope: TelescopeDesignState;
  telescopeLabOpen: boolean;
  missionVizTimeline: number;
  missionVizAutoPlay: boolean;
  missionVizTargetPlanet: PlanetId;

  emergency: EmergencyEvent | null;
  activeChoice: ActiveChoice | null;
  missionOutcome: MissionOutcome | null;

  audioMuted: boolean;
  ambientHumEnabled: boolean;
  roverAudioEnabled: boolean;
  speechEnabled: boolean;
  shadowsEnabled: boolean;
  settings: GameSettings;
  hasSavedGame: boolean;
  toastText: string | null;
  lastDamageAt: number;

  setLang: (lang: Language) => void;
  toggleLang: () => void;
  setDifficulty: (diff: DifficultyLevel) => void;
  setScreen: (screen: GameScreen) => void;
  setSceneEnv: (env: SceneEnv) => void;
  updateCharacter: (patch: Partial<CharacterConfig>) => void;
  startNewGameFlow: () => void;
  completeCharacterSetup: () => void;
  continueSavedGame: () => void;
  saveProgress: () => void;

  selectShipPart: (partId: string) => void;
  selectLivery: (liveryId: ShipLiveryId) => void;
  setMissionPlan: (patch: Partial<TabletMissionPlan>) => void;
  assignCrew: (crewId: string, assignment: CrewMember['assignment']) => void;
  assignSpecialistToRoom: (specialistId: SpecialistId, roomId: ShuttleRoomId) => void;
  swapSpecialists: (idA: SpecialistId, idB: SpecialistId) => void;
  applyPersonnelPreset: (preset: 'balanced' | 'science' | 'repair') => void;

  setTabletOpen: (open: boolean, tab?: GameStoreState['tabletTab']) => void;
  setSkyOpen: (open: boolean) => void;
  setMapOpen: (open: boolean) => void;
  setGuideOpen: (open: boolean) => void;
  setDashboardOpen: (open: boolean, tab?: GameStoreState['dashboardTab']) => void;
  setDashboardTab: (tab: GameStoreState['dashboardTab']) => void;
  setMode2dOpen: (open: boolean, tab?: GameStoreState['mode2dTab']) => void;
  setMode2dTab: (tab: GameStoreState['mode2dTab']) => void;
  setMouseLockedState: (locked: boolean) => void;
  toggleMouseLock: () => void;
  setTouchPadOpen: (touchPadOpen: boolean) => void;
  setVirtualInput: (input: VirtualInputState) => void;

  setCmlLevel: (level: 1 | 2 | 3 | 4) => void;
  setTelescopeLabOpen: (open: boolean) => void;
  updateTelescopeDesign: (patch: Partial<TelescopeDesignState>) => void;
  calibrateAndLaunchTelescope: () => void;
  advanceCubeSatPhase: () => void;
  openMissionViz: (targetPlanet?: PlanetId) => void;
  setMissionVizTimeline: (timeline: number) => void;
  setMissionVizAutoPlay: (autoPlay: boolean) => void;
  setMissionVizTargetPlanet: (planet: PlanetId) => void;

  pushSkyMessage: (text: string, mood?: SkyMood, speak?: boolean, voiceText?: string) => void;
  sendSkyUserQuery: (query: string) => void;
  showToast: (text: string) => void;

  returnToBridge: () => void;
  jumpToShuttleSection: (stationId: InteriorStationId) => void;
  takeLoungeBreak: () => void;
  harvestBioBay: () => void;
  runMedBayScan: () => void;
  inspectCargoBay: () => void;
  talkCommsOfficer: () => void;
  boardShipAndLaunch: () => void;
  flyToPlanet: (planetId: PlanetId, autopilot?: boolean) => void;
  setAutopilot: (active: boolean) => void;
  landOnPlanet: (planetId: PlanetId) => void;
  toggleRover: () => void;
  fireOrScan: () => void;
  triggerBarrelRoll: () => void;
  cycleWeather: () => void;
  setWeather: (weather: SpaceWeather) => void;
  setCameraMode: (mode: CameraMode) => void;

  updateInteriorTelemetry: (snap: InteriorTelemetrySnapshot) => void;
  updateSpaceTelemetry: (snap: SpaceTelemetrySnapshot) => void;
  updateSurfaceTelemetry: (snap: SurfaceTelemetrySnapshot) => void;
  onOrbitArrived: (planetId: PlanetId) => void;
  onWeatherChanged: (weather: SpaceWeather) => void;
  onRingPassed: () => void;
  onAsteroidMined: () => void;
  onAsteroidHit: () => void;
  onBarrelRollPerformed: () => void;
  onRoverToggled: (inRover: boolean) => void;
  onSampleCollected: (sampleId: string, planetId: PlanetId) => void;
  onCraterDiscovered: (craterId: string) => void;
  onScienceSiteCompleted: (siteId: string, dataMb: number) => void;
  onMonolithInspected: () => void;
  onCreatureScanned: (creatureId: string, speciesName: string) => void;
  onPickupCollected: (pickupId: string, pickupType: 'o2' | 'energy') => void;
  onAlienDisturbed: (speciesNameEn: string, speciesNameAr: string) => void;
  onAlienAttack: (speciesNameEn: string, speciesNameAr: string, inRover: boolean) => void;
  onSpacecraftRefuel: (full?: boolean) => void;
  respawnAtSpacecraft: () => void;
  setOutpostMenuOpen: (open: boolean) => void;
  buildSurfaceStructure: (kind: SurfaceBuildingKind) => void;

  transmitDataPacket: () => void;
  cycleCommsStation: () => void;
  resolveEmergency: () => void;
  resolveChoiceOption: (optionId: string) => void;
  finishExpedition: (success: boolean, failureReason?: Record<Language, string>) => void;
  setStoryIntroOpen: (open: boolean) => void;
  setActiveSurvivalId: (id: string | null) => void;
  resolveSurvivalMission: (
    missionId: string,
    won: boolean,
    reasonText?: Record<Language, string>
  ) => void;
  retrySurvivalCampaign: () => void;
  openSurvivalDashboard2d: () => void;
  performAstronautAction: (
    action:
      | 'pace_breathing'
      | 'purge_co2'
      | 'prebreathe_o2'
      | 'toggle_tether'
      | 'set_lcvg'
      | 'set_temp_sim'
      | 'complete_eva_repair',
    value?: number
  ) => void;
  stepEvaExertion: (dt: number, solarZone: 'sunlit' | 'eclipse', thrusting: boolean) => void;
  setArchitectOpen: (open: boolean) => void;
  recordArchitectRun: (run: SavedArchitectRun) => void;

  toggleMute: () => void;
  toggleAmbientHum: () => void;
  toggleRoverAudio: () => void;
  toggleSpeech: () => void;
  toggleShadows: () => void;
  updateSettings: (patch: Partial<GameSettings>) => void;
  applyQualityPreset: (preset: QualityPreset) => void;
  simulationTick: (dt: number) => void;
}

function readInitialLang(): Language {
  try {
    const saved = localStorage.getItem(LANG_KEY);
    if (saved === 'en' || saved === 'ar') return saved;
  } catch {
    // ignore
  }
  return 'ar';
}

function hasSavedInStorage(): boolean {
  try {
    return Boolean(localStorage.getItem(SAVE_KEY));
  } catch {
    return false;
  }
}

const ARCHITECT_RUNS_KEY = 'nova_architect_runs_v1';

function readArchitectRuns(): SavedArchitectRun[] {
  try {
    const raw = localStorage.getItem(ARCHITECT_RUNS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {
    // ignore
  }
  return [...BASELINE_LEADERBOARD];
}

const initialAudioPrefs = readInitialAudioPrefs();
const initialSettings = readInitialSettings();
spaceAudio.setMuted(initialAudioPrefs.audioMuted);
spaceAudio.setAmbientHumEnabled(initialAudioPrefs.ambientHumEnabled);
spaceAudio.setRoverAudioEnabled(initialAudioPrefs.roverAudioEnabled);
spaceAudio.setSpeechEnabled(initialAudioPrefs.speechEnabled);
spaceAudio.setMasterVolume(initialSettings.masterVolume);

export const useGameStore = create<GameStoreState>((set, get) => ({
  lang: readInitialLang(),
  screen: 'menu',
  sceneEnv: 'builder',
  difficulty: 'Commander',
  chapter: 1,
  character: { ...DEFAULT_CHARACTER },
  shipConfig: { ...DEFAULT_SHIP },
  shipMetrics: computeShipMetrics(DEFAULT_SHIP),
  resources: makeInitialResources('Commander'),
  crew: INITIAL_CREW.map((c) => ({ ...c })),
  specialists: INITIAL_SPECIALISTS.map((sp) => ({ ...sp })),
  personnelEffects: computePersonnelEffects(INITIAL_SPECIALISTS),
  missionPlan: { objective: 'signal', autoTransmit: false },

  activePlanet: 'luna',
  discoveredPlanets: ['luna'],
  discoveredCraterIds: [],
  completedScienceSiteIds: [],
  collectedSampleIds: [],
  scannedCreatureIds: [],
  surfaceBuildings: [],
  outpostMenuOpen: false,
  monolithInspected: false,
  pilotingRover: false,
  cameraMode: 'chase',

  ringsPassed: 0,
  asteroidsMined: 0,
  barrelRolls: 0,
  weather: 'clear',

  interiorTelemetry: DEFAULT_INTERIOR_TELEMETRY,
  spaceTelemetry: DEFAULT_SPACE_TELEMETRY,
  surfaceTelemetry: DEFAULT_SURFACE_TELEMETRY,
  virtualInput: { thrust: 0, yaw: 0, pitch: 0, boost: false },
  touchPadOpen: false,

  skyMessages: [],
  skyMood: 'happy',
  skyOpen: false,
  tabletOpen: false,
  tabletTab: 'overview',
  mapOpen: false,
  guideOpen: false,
  dashboardOpen: false,
  dashboardTab: 'overview',
  mode2dOpen: false,
  mode2dTab: 'dashboard2d',
  mouseLocked: false,
  storyIntroOpen: false,
  architectOpen: false,
  architectRuns: readArchitectRuns(),

  hullIntegrity: 100,
  survivalFailures: 0,
  survivalScore: 0,
  survivalStreak: 0,
  completedSurvivalIds: [],
  failedSurvivalIds: [],
  activeSurvivalId: SURVIVAL_MISSIONS[0].id,
  astronautBio: { ...DEFAULT_ASTRONAUT_BIO },

  cmlLevel: 1,
  telescope: {
    objectiveId: 'deep_galaxies',
    wavelengthId: 'infrared',
    opticId: 'segmented_ir',
    cubeSatPhase: 1,
    deployedCount: 0,
    lastMatchedNasaMission: null,
  },
  telescopeLabOpen: false,
  missionVizTimeline: 0.35,
  missionVizAutoPlay: true,
  missionVizTargetPlanet: 'mars',

  emergency: null,
  activeChoice: null,
  missionOutcome: null,

  audioMuted: initialAudioPrefs.audioMuted,
  ambientHumEnabled: initialAudioPrefs.ambientHumEnabled,
  roverAudioEnabled: initialAudioPrefs.roverAudioEnabled,
  speechEnabled: initialAudioPrefs.speechEnabled,
  shadowsEnabled: initialSettings.qualityPreset !== 'low',
  settings: initialSettings,
  hasSavedGame: hasSavedInStorage(),
  toastText: null,
  lastDamageAt: 0,

  setLang: (lang) => {
    try {
      localStorage.setItem(LANG_KEY, lang);
    } catch {
      // ignore
    }
    set({ lang });
  },

  toggleLang: () => {
    const next = get().lang === 'ar' ? 'en' : 'ar';
    get().setLang(next);
  },

  setDifficulty: (difficulty) => {
    set({ difficulty, resources: makeInitialResources(difficulty) });
  },

  setScreen: (screen) => set({ screen }),

  setSceneEnv: (sceneEnv) => set({ sceneEnv }),

  updateCharacter: (patch) =>
    set((s) => ({ character: { ...s.character, ...patch } })),

  startNewGameFlow: () => {
    const diff = get().difficulty;
    set({
      screen: 'character',
      sceneEnv: 'builder',
      chapter: 1,
      shipConfig: { ...DEFAULT_SHIP },
      shipMetrics: computeShipMetrics(DEFAULT_SHIP),
      resources: makeInitialResources(diff),
      crew: INITIAL_CREW.map((c) => ({ ...c })),
      specialists: INITIAL_SPECIALISTS.map((sp) => ({ ...sp })),
      personnelEffects: computePersonnelEffects(INITIAL_SPECIALISTS),
      activePlanet: 'luna',
      discoveredPlanets: ['luna'],
      discoveredCraterIds: [],
      completedScienceSiteIds: [],
      collectedSampleIds: [],
      scannedCreatureIds: [],
      surfaceBuildings: [],
      outpostMenuOpen: false,
      monolithInspected: false,
      pilotingRover: false,
      ringsPassed: 0,
      asteroidsMined: 0,
      barrelRolls: 0,
      weather: 'clear',
      emergency: null,
      activeChoice: null,
      missionOutcome: null,
      skyMessages: [],
      storyIntroOpen: false,
      hullIntegrity: 100,
      survivalFailures: 0,
      survivalScore: 0,
      survivalStreak: 0,
      completedSurvivalIds: [],
      failedSurvivalIds: [],
      activeSurvivalId: SURVIVAL_MISSIONS[0].id,
      astronautBio: { ...DEFAULT_ASTRONAUT_BIO },
    });
  },

  completeCharacterSetup: () => {
    const { character, lang } = get();
    const cleanedName = character.name.trim() || (lang === 'ar' ? 'كابتن طارق' : 'Capt. Nova');
    const updatedChar = { ...character, name: cleanedName };
    const greeting = skyGreeting(cleanedName, lang);

    // BASE EXPERIENCE: Player starts INSIDE the realistic Spacecraft Bridge with Story Intro!
    set({
      character: updatedChar,
      screen: 'playing',
      sceneEnv: 'interior',
      cameraMode: 'first-person',
      tabletOpen: false,
      skyOpen: false,
      storyIntroOpen: true,
      hullIntegrity: 100,
      survivalFailures: 0,
      survivalScore: 0,
      survivalStreak: 0,
      completedSurvivalIds: [],
      failedSurvivalIds: [],
      activeSurvivalId: SURVIVAL_MISSIONS[0].id,
      astronautBio: { ...DEFAULT_ASTRONAUT_BIO },
      skyMessages: [
        {
          id: msgCounter++,
          sender: 'sky',
          text: greeting.text,
          voiceText: greeting.voiceText,
          mood: 'excited',
          timestamp: Date.now(),
        },
      ],
      skyMood: 'excited',
    });

    spaceAudio.speakSky(greeting.voiceText);
    setTimeout(() => {
      engineBridge?.enterInteriorBridge();
    }, 60);
    get().saveProgress();
  },

  continueSavedGame: () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      const shipConfig: ShipConfig = parsed.shipConfig || DEFAULT_SHIP;
      const greeting = skyGreeting(parsed.character?.name || '', get().lang);
      const savedSpecialists: ShuttleSpecialist[] = Array.isArray(parsed.specialists)
        ? INITIAL_SPECIALISTS.map((def) => {
            const match = parsed.specialists.find((x: ShuttleSpecialist) => x.id === def.id);
            return match ? { ...def, assignedRoomId: match.assignedRoomId } : { ...def };
          })
        : INITIAL_SPECIALISTS.map((sp) => ({ ...sp }));
      set({
        screen: 'playing',
        sceneEnv: parsed.sceneEnv || 'interior',
        difficulty: parsed.difficulty || 'Commander',
        chapter: parsed.chapter || 1,
        character: parsed.character
          ? { gender: 'male', ...parsed.character }
          : DEFAULT_CHARACTER,
        shipConfig,
        shipMetrics: computeShipMetrics(shipConfig),
        resources: parsed.resources
          ? { suitHealth: 100, suitCoolant: 100, ...parsed.resources }
          : makeInitialResources('Commander'),
        specialists: savedSpecialists,
        personnelEffects: computePersonnelEffects(savedSpecialists),
        activePlanet: parsed.activePlanet || 'luna',
        discoveredPlanets: parsed.discoveredPlanets || ['luna'],
        discoveredCraterIds: parsed.discoveredCraterIds || [],
        completedScienceSiteIds: parsed.completedScienceSiteIds || [],
        collectedSampleIds: parsed.collectedSampleIds || [],
        scannedCreatureIds: parsed.scannedCreatureIds || [],
        surfaceBuildings: parsed.surfaceBuildings || [],
        monolithInspected: Boolean(parsed.monolithInspected),
        ringsPassed: parsed.ringsPassed || 0,
        asteroidsMined: parsed.asteroidsMined || 0,
        barrelRolls: parsed.barrelRolls || 0,
        hullIntegrity: typeof parsed.hullIntegrity === 'number' ? parsed.hullIntegrity : 100,
        survivalFailures: typeof parsed.survivalFailures === 'number' ? parsed.survivalFailures : 0,
        survivalScore: typeof parsed.survivalScore === 'number' ? parsed.survivalScore : 0,
        survivalStreak: typeof parsed.survivalStreak === 'number' ? parsed.survivalStreak : 0,
        completedSurvivalIds: Array.isArray(parsed.completedSurvivalIds) ? parsed.completedSurvivalIds : [],
        failedSurvivalIds: Array.isArray(parsed.failedSurvivalIds) ? parsed.failedSurvivalIds : [],
        activeSurvivalId: parsed.activeSurvivalId || SURVIVAL_MISSIONS[0].id,
        skyMessages: [
          {
            id: msgCounter++,
            sender: 'sky',
            text: greeting.text,
            voiceText: greeting.voiceText,
            mood: 'happy',
            timestamp: Date.now(),
          },
        ],
      });
      spaceAudio.speakSky(greeting.voiceText);
    } catch {
      get().startNewGameFlow();
    }
  },

  saveProgress: () => {
    const s = get();
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({
          difficulty: s.difficulty,
          chapter: s.chapter,
          sceneEnv: s.sceneEnv,
          character: s.character,
          shipConfig: s.shipConfig,
          resources: s.resources,
          specialists: s.specialists,
          activePlanet: s.activePlanet,
          discoveredPlanets: s.discoveredPlanets,
          discoveredCraterIds: s.discoveredCraterIds,
          completedScienceSiteIds: s.completedScienceSiteIds,
          collectedSampleIds: s.collectedSampleIds,
          scannedCreatureIds: s.scannedCreatureIds,
          surfaceBuildings: s.surfaceBuildings,
          monolithInspected: s.monolithInspected,
          ringsPassed: s.ringsPassed,
          asteroidsMined: s.asteroidsMined,
          barrelRolls: s.barrelRolls,
          hullIntegrity: s.hullIntegrity,
          survivalFailures: s.survivalFailures,
          survivalScore: s.survivalScore,
          survivalStreak: s.survivalStreak,
          completedSurvivalIds: s.completedSurvivalIds,
          failedSurvivalIds: s.failedSurvivalIds,
          activeSurvivalId: s.activeSurvivalId,
        })
      );
      set({ hasSavedGame: true });
    } catch {
      // ignore
    }
  },

  selectShipPart: (partId) => {
    const s = get();
    const nextConfig = { ...s.shipConfig };
    if (partId.startsWith('eng_')) nextConfig.engineId = partId;
    else if (partId.startsWith('sol_')) nextConfig.solarId = partId;
    else if (partId.startsWith('hull_')) nextConfig.hullId = partId;
    else if (partId.startsWith('sen_')) nextConfig.sensorId = partId;
    else if (partId.startsWith('com_')) nextConfig.commsId = partId;

    const metrics = computeShipMetrics(nextConfig);
    set({
      shipConfig: nextConfig,
      shipMetrics: metrics,
      resources: { ...s.resources, mass: metrics.mass },
    });
    spaceAudio.playSkyChirp();
    get().saveProgress();
  },

  selectLivery: (liveryId) => {
    const s = get();
    const nextConfig = { ...s.shipConfig, liveryId };
    set({ shipConfig: nextConfig });
    const livery = SHIP_LIVERIES.find((l) => l.id === liveryId);
    if (livery) get().showToast(livery.name[s.lang]);
    spaceAudio.playSkyChirp();
    get().saveProgress();
  },

  setMissionPlan: (patch) =>
    set((s) => ({ missionPlan: { ...s.missionPlan, ...patch } })),

  assignCrew: (crewId, assignment) =>
    set((s) => ({
      crew: s.crew.map((m) => (m.id === crewId ? { ...m, assignment } : m)),
    })),

  assignSpecialistToRoom: (specialistId, roomId) => {
    const s = get();
    const nextSpecialists = s.specialists.map((sp) =>
      sp.id === specialistId ? { ...sp, assignedRoomId: roomId } : sp
    );
    const nextEffects = computePersonnelEffects(nextSpecialists);
    set({ specialists: nextSpecialists, personnelEffects: nextEffects });
    const spObj = nextSpecialists.find((x) => x.id === specialistId);
    if (spObj) {
      get().showToast(
        s.lang === 'ar'
          ? `تم نقل ${spObj.name.ar} — كفاءة الإصلاح ${nextEffects.repairSpeedMult}x • العلوم ${nextEffects.scienceRateMult}x`
          : `Reassigned ${spObj.name.en} — Repair ${nextEffects.repairSpeedMult}x • Science ${nextEffects.scienceRateMult}x`
      );
    }
    spaceAudio.playSkyChirp();
    get().saveProgress();
  },

  swapSpecialists: (idA, idB) => {
    const s = get();
    const spA = s.specialists.find((x) => x.id === idA);
    const spB = s.specialists.find((x) => x.id === idB);
    if (!spA || !spB || idA === idB) return;
    const nextSpecialists = s.specialists.map((sp) => {
      if (sp.id === idA) return { ...sp, assignedRoomId: spB.assignedRoomId };
      if (sp.id === idB) return { ...sp, assignedRoomId: spA.assignedRoomId };
      return sp;
    });
    const nextEffects = computePersonnelEffects(nextSpecialists);
    set({ specialists: nextSpecialists, personnelEffects: nextEffects });
    spaceAudio.playSkyChirp();
    get().saveProgress();
  },

  applyPersonnelPreset: (preset) => {
    const s = get();
    const mapByPreset: Record<SpecialistId, ShuttleRoomId> =
      preset === 'science'
        ? {
            ryan: 'helm',
            nadia: 'science_lab',
            elena: 'science_lab',
            omar: 'science_lab',
            maya: 'bio_bay',
            sophia: 'bio_bay',
            marcus: 'nav',
            devon: 'engineering',
            aria: 'comms_desk',
            leo: 'nav',
          }
        : preset === 'repair'
          ? {
              ryan: 'helm',
              nadia: 'nav',
              elena: 'science_lab',
              omar: 'med_bay',
              maya: 'engineering',
              sophia: 'med_bay',
              marcus: 'engineering',
              devon: 'engineering',
              aria: 'comms_desk',
              leo: 'cargo_bay',
            }
          : {
              ryan: 'helm',
              nadia: 'nav',
              elena: 'science_lab',
              omar: 'bio_bay',
              maya: 'lounge',
              sophia: 'med_bay',
              marcus: 'engineering',
              devon: 'cargo_bay',
              aria: 'comms_desk',
              leo: 'airlock',
            };

    const nextSpecialists = s.specialists.map((sp) => ({
      ...sp,
      assignedRoomId: mapByPreset[sp.id] || sp.assignedRoomId,
    }));
    const nextEffects = computePersonnelEffects(nextSpecialists);
    set({ specialists: nextSpecialists, personnelEffects: nextEffects });
    get().showToast(
      s.lang === 'ar'
        ? `تم تفعيل تشكيلة الطاقم — الإصلاح ${nextEffects.repairSpeedMult}x • العلوم ${nextEffects.scienceRateMult}x`
        : `Crew Roster Applied — Repair ${nextEffects.repairSpeedMult}x • Science ${nextEffects.scienceRateMult}x`
    );
    spaceAudio.playRingPass();
    get().saveProgress();
  },

  setTabletOpen: (open, tab) =>
    set((s) => {
      if (open) engineBridge?.setMouseLocked(false);
      return {
        tabletOpen: open,
        tabletTab: tab ?? s.tabletTab,
        mapOpen: open ? false : s.mapOpen,
        guideOpen: open ? false : s.guideOpen,
        telescopeLabOpen: open ? false : s.telescopeLabOpen,
        dashboardOpen: open ? false : s.dashboardOpen,
        mode2dOpen: open ? false : s.mode2dOpen,
      };
    }),

  setSkyOpen: (skyOpen) => {
    if (skyOpen) engineBridge?.setMouseLocked(false);
    set({ skyOpen });
  },
  setMapOpen: (mapOpen) =>
    set((s) => {
      if (mapOpen) engineBridge?.setMouseLocked(false);
      return {
        mapOpen,
        tabletOpen: mapOpen ? false : s.tabletOpen,
        telescopeLabOpen: mapOpen ? false : s.telescopeLabOpen,
        dashboardOpen: mapOpen ? false : s.dashboardOpen,
        mode2dOpen: mapOpen ? false : s.mode2dOpen,
      };
    }),
  setGuideOpen: (guideOpen) =>
    set((s) => {
      if (guideOpen) engineBridge?.setMouseLocked(false);
      return {
        guideOpen,
        tabletOpen: guideOpen ? false : s.tabletOpen,
        telescopeLabOpen: guideOpen ? false : s.telescopeLabOpen,
        dashboardOpen: guideOpen ? false : s.dashboardOpen,
        mode2dOpen: guideOpen ? false : s.mode2dOpen,
      };
    }),
  setDashboardOpen: (dashboardOpen, tab) =>
    set((s) => {
      if (dashboardOpen) {
        engineBridge?.setMouseLocked(false);
        const msg = skyEventText('main_dashboard', s.character.name, s.lang);
        spaceAudio.playSkyChirp();
        return {
          dashboardOpen,
          dashboardTab: tab ?? s.dashboardTab,
          tabletOpen: false,
          mapOpen: false,
          guideOpen: false,
          telescopeLabOpen: false,
          mode2dOpen: false,
          skyMood: msg.mood,
        };
      }
      return { dashboardOpen };
    }),
  setDashboardTab: (dashboardTab) => set({ dashboardTab }),
  setMode2dOpen: (mode2dOpen, tab) =>
    set((s) => {
      if (mode2dOpen) {
        engineBridge?.setMouseLocked(false);
        const msg = skyEventText('control_2d', s.character.name, s.lang);
        spaceAudio.speakSky(msg.voiceText);
      }
      return {
        mode2dOpen,
        mode2dTab: tab ?? s.mode2dTab,
        tabletOpen: mode2dOpen ? false : s.tabletOpen,
        mapOpen: mode2dOpen ? false : s.mapOpen,
        guideOpen: mode2dOpen ? false : s.guideOpen,
        telescopeLabOpen: mode2dOpen ? false : s.telescopeLabOpen,
        dashboardOpen: mode2dOpen ? false : s.dashboardOpen,
      };
    }),
  setMode2dTab: (mode2dTab) => set({ mode2dTab }),
  setMouseLockedState: (mouseLocked) => set({ mouseLocked }),
  toggleMouseLock: () => engineBridge?.toggleMouseLock(),
  setTouchPadOpen: (touchPadOpen) => set({ touchPadOpen }),
  setVirtualInput: (virtualInput) => set({ virtualInput }),

  setCmlLevel: (cmlLevel) => set({ cmlLevel }),
  setTelescopeLabOpen: (telescopeLabOpen) =>
    set((s) => {
      if (telescopeLabOpen) engineBridge?.setMouseLocked(false);
      return {
        telescopeLabOpen,
        tabletOpen: telescopeLabOpen ? false : s.tabletOpen,
        mapOpen: telescopeLabOpen ? false : s.mapOpen,
        guideOpen: telescopeLabOpen ? false : s.guideOpen,
        dashboardOpen: telescopeLabOpen ? false : s.dashboardOpen,
        mode2dOpen: telescopeLabOpen ? false : s.mode2dOpen,
      };
    }),
  updateTelescopeDesign: (patch) =>
    set((s) => ({ telescope: { ...s.telescope, ...patch } })),

  calibrateAndLaunchTelescope: () => {
    const s = get();
    const obj = TELESCOPE_OBJECTIVES.find((o) => o.id === s.telescope.objectiveId);
    if (!obj) return;

    const matched =
      s.telescope.wavelengthId === obj.idealWavelength &&
      s.telescope.opticId === obj.idealOptic;

    if (matched) {
      const sciMult = s.personnelEffects.scienceRateMult;
      const bonusData = Math.round(55 * sciMult);
      const bonusCredits = Math.round(120 * sciMult);
      set((state) => ({
        cmlLevel: Math.max(state.cmlLevel, 3) as 1 | 2 | 3 | 4,
        telescope: {
          ...state.telescope,
          deployedCount: state.telescope.deployedCount + 1,
          lastMatchedNasaMission: obj.nasaAnalog,
        },
        resources: {
          ...state.resources,
          credits: state.resources.credits + bonusCredits,
          dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + bonusData),
          dataCollected: state.resources.dataCollected + bonusData,
        },
      }));
      const msg = skyEventText('telescope_success', s.character.name, s.lang, undefined, obj.nasaAnalog);
      get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
      spaceAudio.playPlanetFanfare();
      get().saveProgress();
    } else {
      const msg = skyEventText('telescope_mismatch', s.character.name, s.lang);
      get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
      spaceAudio.playWeatherAlert('storm');
    }
  },

  advanceCubeSatPhase: () => {
    const s = get();
    const sciMult = s.personnelEffects.scienceRateMult;
    const bonusData = Math.round(35 * sciMult);
    const bonusCredits = Math.round(75 * sciMult);
    const nextPhase = Math.min(4, s.telescope.cubeSatPhase + 1) as 1 | 2 | 3 | 4;
    const phaseInfo = CUBESAT_PHASES.find((p) => p.phase === nextPhase);
    set((state) => ({
      cmlLevel: nextPhase >= 3 ? (Math.max(state.cmlLevel, 4) as 1 | 2 | 3 | 4) : state.cmlLevel,
      telescope: { ...state.telescope, cubeSatPhase: nextPhase },
      resources: {
        ...state.resources,
        credits: state.resources.credits + bonusCredits,
        dataCollected: state.resources.dataCollected + bonusData,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + bonusData),
      },
    }));
    const msg = skyEventText(
      'cubesat_advance',
      s.character.name,
      s.lang,
      undefined,
      phaseInfo?.title[s.lang] || phaseInfo?.title.en
    );
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playRingPass();
    get().saveProgress();
  },

  openMissionViz: (targetPlanet) => {
    const s = get();
    const target = targetPlanet || s.missionVizTargetPlanet || 'mars';
    const planet = PLANETS.find((p) => p.id === target) || PLANETS[1];
    set({
      sceneEnv: 'mission-viz',
      missionVizTargetPlanet: target,
      tabletOpen: false,
      mapOpen: false,
      telescopeLabOpen: false,
      cmlLevel: Math.max(s.cmlLevel, 3) as 1 | 2 | 3 | 4,
    });
    engineBridge?.setMissionVizState(s.missionVizTimeline, target);
    const msg = skyEventText('mission_viz', s.character.name, s.lang, planet);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playSkyChirp();
  },

  setMissionVizTimeline: (missionVizTimeline) => {
    const clamped = Math.max(0, Math.min(1, missionVizTimeline));
    set({ missionVizTimeline: clamped });
    engineBridge?.setMissionVizState(clamped, get().missionVizTargetPlanet);
  },

  setMissionVizAutoPlay: (missionVizAutoPlay) => set({ missionVizAutoPlay }),

  setMissionVizTargetPlanet: (missionVizTargetPlanet) => {
    set({ missionVizTargetPlanet });
    engineBridge?.setMissionVizState(get().missionVizTimeline, missionVizTargetPlanet);
  },

  pushSkyMessage: (text, mood = 'happy', speak = false, voiceText) => {
    set((s) => ({
      skyMood: mood,
      skyMessages: [
        ...s.skyMessages.slice(-24),
        {
          id: msgCounter++,
          sender: 'sky',
          text,
          voiceText,
          mood,
          timestamp: Date.now(),
        },
      ],
    }));
    if (speak && voiceText) {
      spaceAudio.speakSky(voiceText);
    }
  },

  sendSkyUserQuery: (query) => {
    const s = get();
    const trimmed = query.trim();
    if (!trimmed) return;
    const planet = PLANETS.find((p) => p.id === s.activePlanet) || PLANETS[0];
    const reply = generateSkyChatReply({
      query: trimmed,
      playerName: s.character.name,
      lang: s.lang,
      metrics: s.shipMetrics,
      resources: s.resources,
      activePlanet: planet,
      weather: s.weather,
      discoveredCount: s.discoveredPlanets.length,
    });

    set((state) => ({
      skyMood: reply.mood,
      skyMessages: [
        ...state.skyMessages.slice(-22),
        {
          id: msgCounter++,
          sender: 'player',
          text: trimmed,
          mood: 'calm',
          timestamp: Date.now(),
        },
        {
          id: msgCounter++,
          sender: 'sky',
          text: reply.text,
          voiceText: reply.voiceText,
          mood: reply.mood,
          timestamp: Date.now() + 1,
        },
      ],
    }));
    spaceAudio.speakSky(reply.voiceText);
  },

  showToast: (toastText) => {
    set({ toastText });
    window.setTimeout(() => {
      if (get().toastText === toastText) {
        set({ toastText: null });
      }
    }, 3000);
  },

  returnToBridge: () => {
    const s = get();
    set((state) => ({
      sceneEnv: 'interior',
      pilotingRover: false,
      cameraMode: 'first-person',
      tabletOpen: false,
      mapOpen: false,
      resources: {
        ...state.resources,
        suitO2: 100,
        battery: 100,
        suitHealth: 100,
        suitCoolant: 100,
      },
      astronautBio: {
        ...state.astronautBio,
        co2MmHg: 1.0,
        suitTempC: 21.5,
        suitPressureKpa: 29.6,
        heartRateBpm: 74,
        stressLevel: 'CALM',
      },
    }));
    engineBridge?.enterInteriorBridge();
    const msg = skyEventText('return_bridge', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    get().showToast(
      s.lang === 'ar'
        ? 'تم شحن الأكسجين والطاقة وصحة البدلة 100% داخل المركبة ✓'
        : 'Docked Inside Spacecraft: O2, Power, Coolant & Suit Health Refueled 100% ✓'
    );
    spaceAudio.playSkyChirp();
  },

  jumpToShuttleSection: (stationId) => {
    const s = get();
    if (s.sceneEnv !== 'interior') {
      set({
        sceneEnv: 'interior',
        pilotingRover: false,
        cameraMode: 'first-person',
        tabletOpen: false,
        mapOpen: false,
      });
      engineBridge?.enterInteriorBridge();
    }
    engineBridge?.walkToInteriorStation(stationId);
    spaceAudio.playSkyChirp();
  },

  takeLoungeBreak: () => {
    const s = get();
    const lifeMult = s.personnelEffects.lifeSupportRateMult;
    const batteryGain = Math.round(15 * lifeMult);
    set((state) => ({
      resources: {
        ...state.resources,
        suitO2: 100,
        battery: Math.min(100, state.resources.battery + batteryGain),
      },
      crew: state.crew.map((c) => ({
        ...c,
        morale: Math.min(100, c.morale + Math.round(5 * lifeMult)),
        fatigue: Math.max(0, c.fatigue - Math.round(6 * lifeMult)),
      })),
    }));
    const msg = skyEventText('lounge_coffee', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    get().showToast(s.lang === 'ar' ? `استراحة قهوة دافئة ☕ +${batteryGain}% طاقة` : `Warm Coffee Break ☕ +${batteryGain}% PWR`);
  },

  harvestBioBay: () => {
    const s = get();
    const sciMult = s.personnelEffects.scienceRateMult;
    const dataGain = Math.round(40 * sciMult);
    const creditGain = Math.round(55 * sciMult);
    set((state) => ({
      resources: {
        ...state.resources,
        suitO2: 100,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + dataGain),
        dataCollected: state.resources.dataCollected + dataGain,
        credits: state.resources.credits + creditGain,
      },
    }));
    const msg = skyEventText('bio_harvest', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playRingPass();
    get().showToast(
      s.lang === 'ar'
        ? `قسم الزراعة: O2 100% +${dataGain}MB +${creditGain} CR 🌱`
        : `Bio-Dome: O2 100% +${dataGain}MB +${creditGain} CR 🌱`
    );
    get().saveProgress();
  },

  runMedBayScan: () => {
    const s = get();
    const lifeMult = s.personnelEffects.lifeSupportRateMult;
    const radStr = `${s.spaceTelemetry.radiationSievert.toFixed(2)} mSv`;
    set((state) => ({
      resources: {
        ...state.resources,
        suitO2: 100,
      },
      crew: state.crew.map((c) => ({
        ...c,
        morale: Math.min(100, c.morale + Math.round(8 * lifeMult)),
        fatigue: Math.max(0, c.fatigue - Math.round(15 * lifeMult)),
      })),
    }));
    const msg = skyEventText('med_check', s.character.name, s.lang, undefined, radStr);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playSkyChirp();
    get().showToast(s.lang === 'ar' ? `العيادة الطبية: الإشعاع ${radStr} • حالة ممتازة 🩺` : `Med Bay: Radiation ${radStr} • Nominal 🩺`);
  },

  inspectCargoBay: () => {
    const s = get();
    const repMult = s.personnelEffects.repairSpeedMult;
    const battGain = Math.round(10 * repMult);
    const crGain = Math.round(45 * repMult);
    set((state) => ({
      cmlLevel: Math.max(state.cmlLevel, 2) as 1 | 2 | 3 | 4,
      resources: {
        ...state.resources,
        battery: Math.min(100, state.resources.battery + battGain),
        credits: state.resources.credits + crGain,
      },
    }));
    const msg = skyEventText('cargo_prep', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playSkyChirp();
    get().showToast(
      s.lang === 'ar'
        ? `عنبر الروفر جاهز • +${battGain}% طاقة +${crGain} CR 🛰️`
        : `Cargo & Rover Prepped • +${battGain}% PWR +${crGain} CR 🛰️`
    );
    get().saveProgress();
  },

  talkCommsOfficer: () => {
    const s = get();
    if (s.resources.dataStorage > 0) {
      get().transmitDataPacket();
      return;
    }
    const stationLabel = `${s.resources.commsStation} (${s.resources.commsSignal}%)`;
    const msg = skyEventText('comms_desk', s.character.name, s.lang, undefined, stationLabel);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    get().setTabletOpen(true, 'comms');
    spaceAudio.playSkyChirp();
  },

  boardShipAndLaunch: () => {
    const s = get();
    const fromPlanet = s.sceneEnv === 'planet' ? s.activePlanet : undefined;
    set({
      sceneEnv: 'spaceflight',
      pilotingRover: false,
      cameraMode: 'cockpit',
      tabletOpen: false,
      mapOpen: false,
      chapter: Math.max(s.chapter, 2),
    });
    engineBridge?.launchToSpace(fromPlanet);
    engineBridge?.setCameraMode('cockpit');
    const msg = skyEventText('launch', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playBoost();
  },

  flyToPlanet: (planetId, autopilot = true) => {
    const s = get();
    const planet = PLANETS.find((p) => p.id === planetId);
    if (!planet) return;
    if (s.sceneEnv !== 'spaceflight') {
      set({ sceneEnv: 'spaceflight', pilotingRover: false, cameraMode: 'cockpit' });
      engineBridge?.launchToSpace(s.activePlanet);
      engineBridge?.setCameraMode('cockpit');
    }
    set({ tabletOpen: false, mapOpen: false });
    engineBridge?.setTargetPlanet(planetId, autopilot);

    const nLocal = getDisplayCommander(s.character.name, s.lang);
    const nEn = getEnglishCommander(s.character.name);
    const voiceText = `Course locked to ${planet.name.en}, ${nEn}. Engaging autopilot flight vector.`;
    const text =
      s.lang === 'ar'
        ? `تم تحديد المسار نحو ${planet.name.ar} يا ${nLocal}! الطيار الآلي يقود المركبة الآن.`
        : voiceText;
    get().pushSkyMessage(text, 'scanning', true, voiceText);
  },

  setAutopilot: (active) => {
    engineBridge?.setAutopilot(active);
  },

  landOnPlanet: (planetId) => {
    const s = get();
    const planet = PLANETS.find((p) => p.id === planetId) || PLANETS[0];
    const discovered = s.discoveredPlanets.includes(planetId)
      ? s.discoveredPlanets
      : [...s.discoveredPlanets, planetId];

    set({
      sceneEnv: 'planet',
      activePlanet: planetId,
      discoveredPlanets: discovered,
      pilotingRover: false,
      cameraMode: 'chase',
      tabletOpen: false,
      mapOpen: false,
      chapter:
        planetId === 'mars' || planetId === 'obsidian'
          ? Math.max(s.chapter, 4)
          : Math.max(s.chapter, 2),
    });
    engineBridge?.landOnPlanet(planetId);
    const msg = skyEventText('land_planet', s.character.name, s.lang, planet);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playPlanetFanfare();
    get().saveProgress();
  },

  toggleRover: () => {
    if (get().sceneEnv === 'planet') {
      engineBridge?.toggleRover();
    }
  },

  fireOrScan: () => {
    engineBridge?.fireOrScan();
  },

  triggerBarrelRoll: () => {
    engineBridge?.triggerBarrelRoll();
  },

  cycleWeather: () => {
    engineBridge?.cycleWeather();
  },

  setWeather: (weather) => {
    engineBridge?.setWeather(weather);
  },

  setCameraMode: (mode) => {
    set({ cameraMode: mode });
    engineBridge?.setCameraMode(mode);
  },

  updateInteriorTelemetry: (interiorTelemetry) => set({ interiorTelemetry }),
  updateSpaceTelemetry: (spaceTelemetry) => set({ spaceTelemetry }),
  updateSurfaceTelemetry: (surfaceTelemetry) => set({ surfaceTelemetry }),

  onOrbitArrived: (planetId) => {
    const s = get();
    const planet = PLANETS.find((p) => p.id === planetId);
    if (!planet) return;
    const isNew = !s.discoveredPlanets.includes(planetId);
    const nextDiscovered = isNew ? [...s.discoveredPlanets, planetId] : s.discoveredPlanets;
    const sciMult = s.personnelEffects.scienceRateMult;

    set((state) => ({
      activePlanet: planetId,
      discoveredPlanets: nextDiscovered,
      chapter: nextDiscovered.length >= 3 ? Math.max(state.chapter, 3) : state.chapter,
      resources: {
        ...state.resources,
        credits: state.resources.credits + (isNew ? Math.round(planet.rewardCredits * sciMult) : 0),
        dataCollected: state.resources.dataCollected + (isNew ? Math.round(35 * sciMult) : 0),
      },
    }));

    const msg = skyEventText('arrive_orbit', s.character.name, s.lang, planet);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playPlanetFanfare();
    get().saveProgress();
  },

  onWeatherChanged: (weather) => {
    const s = get();
    set({ weather });
    const eventMap: Record<SpaceWeather, Parameters<typeof skyEventText>[0]> = {
      clear: 'weather_clear',
      solar_flare: 'weather_solar_flare',
      asteroid_squall: 'weather_asteroid_squall',
      ion_storm: 'weather_ion_storm',
    };
    const msg = skyEventText(eventMap[weather], s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playWeatherAlert(weather === 'clear' ? 'calm' : 'storm');
  },

  onRingPassed: () => {
    const s = get();
    set((state) => ({
      ringsPassed: state.ringsPassed + 1,
      resources: {
        ...state.resources,
        battery: Math.min(100, state.resources.battery + 8),
        credits: state.resources.credits + 40,
      },
    }));
    const msg = skyEventText('ring', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, false, msg.voiceText);
    spaceAudio.playRingPass();
  },

  onAsteroidMined: () => {
    const s = get();
    set((state) => ({
      asteroidsMined: state.asteroidsMined + 1,
      resources: {
        ...state.resources,
        credits: state.resources.credits + 45,
        dataCollected: state.resources.dataCollected + 10,
      },
    }));
    spaceAudio.playExplosion();
    if (get().asteroidsMined % 3 === 1) {
      const msg = skyEventText('asteroid_mined', s.character.name, s.lang);
      get().pushSkyMessage(msg.text, msg.mood, false, msg.voiceText);
    }
  },

  onAsteroidHit: () => {
    const s = get();
    spaceAudio.playExplosion();
    const msg = skyEventText('asteroid_hit', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
  },

  onBarrelRollPerformed: () => {
    const s = get();
    set((state) => ({ barrelRolls: state.barrelRolls + 1 }));
    spaceAudio.playBoost();
    if (get().barrelRolls % 2 === 1) {
      const msg = skyEventText('barrel_roll', s.character.name, s.lang);
      get().pushSkyMessage(msg.text, msg.mood, false, msg.voiceText);
    }
  },

  onRoverToggled: (inRover) => {
    const s = get();
    set({ pilotingRover: inRover });
    spaceAudio.playRoverLatch(inRover);
    const msg = skyEventText(inRover ? 'rover_enter' : 'rover_exit', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
  },

  onSampleCollected: (sampleId, planetId) => {
    const s = get();
    if (s.collectedSampleIds.includes(sampleId)) return;
    const planet = PLANETS.find((p) => p.id === planetId);
    const sciMult = s.personnelEffects.scienceRateMult;
    const dataGain = Math.round(30 * sciMult);
    const creditGain = Math.round(65 * sciMult);
    set((state) => ({
      collectedSampleIds: [...state.collectedSampleIds, sampleId],
      resources: {
        ...state.resources,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + dataGain),
        dataCollected: state.resources.dataCollected + dataGain,
        credits: state.resources.credits + creditGain,
      },
    }));
    const msg = skyEventText('sample', s.character.name, s.lang, planet);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playRingPass();
    get().saveProgress();
  },

  onCraterDiscovered: (craterId) => {
    const s = get();
    if (s.discoveredCraterIds.includes(craterId)) return;
    const sciMult = s.personnelEffects.scienceRateMult;
    const dataGain = Math.round(40 * sciMult);
    const creditGain = Math.round(80 * sciMult);
    set((state) => ({
      discoveredCraterIds: [...state.discoveredCraterIds, craterId],
      resources: {
        ...state.resources,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + dataGain),
        dataCollected: state.resources.dataCollected + dataGain,
        credits: state.resources.credits + creditGain,
      },
    }));
    const msg = skyEventText('crater', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playPlanetFanfare();
    get().saveProgress();
  },

  onScienceSiteCompleted: (siteId, dataMb) => {
    const s = get();
    if (s.completedScienceSiteIds.includes(siteId)) return;
    const sciMult = s.personnelEffects.scienceRateMult;
    const scaledMb = Math.round(dataMb * sciMult);
    const creditGain = Math.round(110 * sciMult);
    set((state) => ({
      completedScienceSiteIds: [...state.completedScienceSiteIds, siteId],
      resources: {
        ...state.resources,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + scaledMb),
        dataCollected: state.resources.dataCollected + scaledMb,
        credits: state.resources.credits + creditGain,
      },
    }));
    const msg = skyEventText('science', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playPlanetFanfare();
    get().saveProgress();
  },

  onMonolithInspected: () => {
    const s = get();
    if (s.monolithInspected) return;
    set({
      monolithInspected: true,
      chapter: 5,
      activeChoice: {
        id: 'final_signal_choice',
        title: { ar: 'لغز إشارة 2089 الكونية', en: 'The 2089 Harmonic Signal Decision' },
        prompt: {
          ar: `القائد ${getDisplayCommander(s.character.name, 'ar')}، التقطت المسلّة ترددات الحضارة القديمة بالكامل. كيف ستتصرف بهذه البيانات التاريخية؟`,
          en: `Commander ${getEnglishCommander(s.character.name)}, the Monolith has finished resonating with the 2089 harmonic array. How should NOVA broadcast this discovery?`,
        },
        options: [
          {
            id: 'open_beacon',
            label: { ar: 'بث مفتوح للأرض وللمجتمع العلمي', en: 'Open DSN Broadcast to All Humanity' },
            description: {
              ar: 'شارك إحداثيات المسلّة والترددات فوراً عبر شبكة الفضاء العميق.',
              en: 'Beam raw harmonic coordinates publicly across every Deep Space station.',
            },
            effectSummary: { ar: 'نهاية الاكتشاف المفتوح +500 رصيد', en: 'Open Horizon Ending +500 CR' },
          },
          {
            id: 'harness_core',
            label: { ar: 'توجيه طاقة المسلّة لتطوير محركات نوفا', en: 'Channel Signal Into NOVA Warp Core' },
            description: {
              ar: 'استثمر التردد في دفع كمومي يفتح طرق السفر النجمي الأسرع.',
              en: 'Synthesize the frequency to unlock next-generation interstellar propulsion.',
            },
            effectSummary: { ar: 'نهاية طليعة النجوم +500 رصيد', en: 'Starlight Vanguard Ending +500 CR' },
          },
          {
            id: 'continue_roam',
            label: { ar: 'حفظ الشفرة ومواصلة استكشاف الكواكب', en: 'Archive Code & Continue Free Flight' },
            description: {
              ar: 'احتفظ بالاكتشاف واستمر في الطيران الحر بين العوالم الستة.',
              en: 'Log the anomaly and keep flying freely between all 6 worlds.',
            },
            effectSummary: { ar: 'استمرار الطيران الحر', en: 'Continue Sandbox Expedition' },
          },
        ],
      },
    });
    const msg = skyEventText('monolith', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playPlanetFanfare();
  },

  onCreatureScanned: (creatureId, speciesName) => {
    const s = get();
    if (s.scannedCreatureIds.includes(creatureId)) return;
    const sciMult = s.personnelEffects.scienceRateMult;
    const dataGain = Math.round(45 * sciMult);
    const creditGain = Math.round(85 * sciMult);
    set((state) => ({
      scannedCreatureIds: [...state.scannedCreatureIds, creatureId],
      resources: {
        ...state.resources,
        dataStorage: Math.min(state.resources.maxStorage, state.resources.dataStorage + dataGain),
        dataCollected: state.resources.dataCollected + dataGain,
        credits: state.resources.credits + creditGain,
      },
    }));
    const nLocal = getDisplayCommander(s.character.name, s.lang);
    const nEn = getEnglishCommander(s.character.name);
    const voiceText = `Bio-scan complete on ${speciesName}, ${nEn}. Telemetry archived (+${dataGain} MB, +${creditGain} credits).`;
    const text =
      s.lang === 'ar'
        ? `تم مسح الكائن الفضائي «${speciesName}» يا ${nLocal}! (+${dataGain}MB • +${creditGain} CR)`
        : voiceText;
    get().pushSkyMessage(text, 'scanning', true, voiceText);
    get().showToast(
      s.lang === 'ar' ? `مسح بيولوجي: ${speciesName} +${creditGain} CR` : `Bio-Scan: ${speciesName} +${creditGain} CR`
    );
    spaceAudio.playPlanetFanfare();
    get().saveProgress();
  },

  onPickupCollected: (pickupId, pickupType) => {
    const s = get();
    if (s.collectedSampleIds.includes(pickupId)) return;
    set((state) => ({
      collectedSampleIds: [...state.collectedSampleIds, pickupId],
      resources: {
        ...state.resources,
        suitO2: pickupType === 'o2' ? Math.min(100, state.resources.suitO2 + 35) : state.resources.suitO2,
        suitCoolant:
          pickupType === 'o2'
            ? Math.min(100, (state.resources.suitCoolant ?? 100) + 20)
            : state.resources.suitCoolant ?? 100,
        battery:
          pickupType === 'energy' ? Math.min(100, state.resources.battery + 30) : state.resources.battery,
        suitHealth:
          pickupType === 'energy'
            ? Math.min(100, (state.resources.suitHealth ?? 100) + 15)
            : state.resources.suitHealth ?? 100,
        credits: state.resources.credits + 25,
      },
    }));
    spaceAudio.playRingPass();
    get().showToast(
      s.lang === 'ar'
        ? pickupType === 'o2'
          ? 'كبسولة أكسجين +35% O2 و +20% تبريد ✓'
          : 'خلية طاقة شمسية +30% PWR و +15% صحة ✓'
        : pickupType === 'o2'
          ? 'O2 Canister Collected (+35% O2, +20% Coolant)'
          : 'Energy Cell Collected (+30% PWR, +15% Suit Health)'
    );
    get().saveProgress();
  },

  onAlienDisturbed: (speciesNameEn, speciesNameAr) => {
    const s = get();
    const label = s.lang === 'ar' ? speciesNameAr : speciesNameEn;
    spaceAudio.playWeatherAlert('storm');
    get().showToast(
      s.lang === 'ar'
        ? `⚠ أزعجت «${label}»! ابتعد أو عُد للمركبة فوراً!`
        : `⚠ Disturbed ${label}! Evade or retreat to Spacecraft Pad!`
    );
  },

  onAlienAttack: (speciesNameEn, speciesNameAr, inRover) => {
    const s = get();
    if (s.screen !== 'playing') return;
    const hpLoss = inRover ? 9 : 18;
    const o2Loss = inRover ? 6 : 14;
    const pwrLoss = inRover ? 5 : 10;
    const coolLoss = inRover ? 6 : 14;

    const nextHealth = Math.max(0, Math.round((s.resources.suitHealth ?? 100) - hpLoss));
    const nextO2 = Math.max(0, Math.round(s.resources.suitO2 - o2Loss));
    const nextBattery = Math.max(0, Math.round(s.resources.battery - pwrLoss));
    const nextCoolant = Math.max(0, Math.round((s.resources.suitCoolant ?? 100) - coolLoss));
    const nextCo2 = Math.min(6.0, Number((s.astronautBio.co2MmHg + (inRover ? 0.3 : 0.75)).toFixed(2)));
    const nextBpm = Math.min(168, Math.round(s.astronautBio.heartRateBpm + (inRover ? 14 : 26)));

    set({
      lastDamageAt: Date.now(),
      resources: {
        ...s.resources,
        suitHealth: nextHealth,
        suitO2: nextO2,
        battery: nextBattery,
        suitCoolant: nextCoolant,
      },
      astronautBio: {
        ...s.astronautBio,
        co2MmHg: nextCo2,
        heartRateBpm: nextBpm,
        stressLevel: nextHealth < 35 || nextO2 < 30 ? 'CRITICAL' : 'HIGH',
      },
    });

    spaceAudio.playExplosion();
    spaceAudio.playWeatherAlert('storm');

    const label = s.lang === 'ar' ? speciesNameAr : speciesNameEn;
    get().showToast(
      s.lang === 'ar'
        ? `💥 هاجمك «${label}»! (-${hpLoss}% صحة، -${o2Loss}% O2، -${coolLoss}% تبريد) عُد للمركبة!`
        : `💥 Attacked by ${label}! (-${hpLoss}% Suit HP, -${o2Loss}% O2, -${coolLoss}% Coolant) Return to Spacecraft!`
    );

    if (nextO2 <= 0 || nextHealth <= 0) {
      get().finishExpedition(false, {
        ar:
          nextO2 <= 0
            ? `نفد الأكسجين 0% بعد تمزق البدلة إثر هجوم «${speciesNameAr}» قبل العودة للمركبة.`
            : `انهارت صحة البدلة 0% بسبب هجمات «${speciesNameAr}» المتكررة على سطح الكوكب.`,
        en:
          nextO2 <= 0
            ? `Suit Oxygen depleted to 0% from suit breach caused by ${speciesNameEn} before reaching the spacecraft.`
            : `Suit Integrity collapsed to 0% following repeated hostile attacks by ${speciesNameEn}.`,
      });
    }
  },

  onSpacecraftRefuel: () => {
    const s = get();
    set((state) => ({
      resources: {
        ...state.resources,
        suitO2: 100,
        battery: 100,
        suitHealth: 100,
        suitCoolant: 100,
      },
      astronautBio: {
        ...state.astronautBio,
        co2MmHg: 1.0,
        suitTempC: 21.5,
        suitPressureKpa: 29.6,
        heartRateBpm: 74,
        stressLevel: 'CALM',
      },
    }));
    spaceAudio.playRingPass();
    get().showToast(
      s.lang === 'ar'
        ? '⛽ تم إعادة تزويد الأكسجين والصحة والطاقة والتبريد من المركبة 100% ✓'
        : '⛽ Spacecraft Refuel Complete: O2, Suit Health, Power & Coolant 100% ✓'
    );
    const nEn = getEnglishCommander(s.character.name);
    const voice = `Spacecraft umbilical refuel complete, ${nEn}. Oxygen, coolant, battery, and suit seal are back at 100 percent.`;
    get().pushSkyMessage(
      s.lang === 'ar'
        ? 'تمت إعادة تعبئة الأكسجين والطاقة والتبريد وصحة البدلة 100% من المركبة الفضائية!'
        : voice,
      'happy',
      true,
      voice
    );
    get().saveProgress();
  },

  respawnAtSpacecraft: () => {
    const s = get();
    set({
      screen: 'playing',
      sceneEnv: 'interior',
      pilotingRover: false,
      cameraMode: 'first-person',
      missionOutcome: null,
      lastDamageAt: 0,
      resources: {
        ...s.resources,
        suitO2: 100,
        battery: 100,
        suitHealth: 100,
        suitCoolant: 100,
      },
      astronautBio: {
        ...DEFAULT_ASTRONAUT_BIO,
      },
    });
    engineBridge?.enterInteriorBridge();
    spaceAudio.playRingPass();
    get().saveProgress();
  },

  setOutpostMenuOpen: (outpostMenuOpen) => set({ outpostMenuOpen }),

  buildSurfaceStructure: (kind) => {
    const s = get();
    if (s.sceneEnv !== 'planet') {
      get().showToast(
        s.lang === 'ar' ? 'يجب الهبوط على سطح كوكب أولاً لبناء قاعدة.' : 'Land on a planet surface first to build an outpost.'
      );
      return;
    }
    const costMap: Record<SurfaceBuildingKind, number> = {
      habitat: 120,
      solar_relay: 90,
      science_beacon: 110,
    };
    const cost = costMap[kind];
    if (s.resources.credits < cost) {
      get().showToast(
        s.lang === 'ar' ? `رصيد غير كافٍ (المطلوب ${cost} CR)` : `Insufficient credits (${cost} CR required)`
      );
      return;
    }
    const rec = engineBridge?.buildSurfaceStructure(kind);
    if (!rec) return;

    const labelMap: Record<SurfaceBuildingKind, { ar: string; en: string }> = {
      habitat: { ar: 'قبة سكن وأكسجين', en: 'Habitat O2 Dome' },
      solar_relay: { ar: 'محطة طاقة شمسية', en: 'Solar Power Relay' },
      science_beacon: { ar: 'منارة أبحاث علمية', en: 'Science Telemetry Beacon' },
    };

    set((state) => ({
      surfaceBuildings: [...state.surfaceBuildings, rec],
      resources: {
        ...state.resources,
        credits: Math.max(0, state.resources.credits - cost),
      },
    }));
    spaceAudio.playRingPass();
    get().showToast(
      s.lang === 'ar' ? `تم بناء ${labelMap[kind].ar} ✓` : `Constructed ${labelMap[kind].en} ✓`
    );
    const nEn = getEnglishCommander(s.character.name);
    const voiceText = `${labelMap[kind].en} deployed on surface, ${nEn}. Outpost telemetry online.`;
    get().pushSkyMessage(
      s.lang === 'ar' ? `تم نشر ${labelMap[kind].ar} على السطح بنجاح!` : voiceText,
      'happy',
      true,
      voiceText
    );
    get().saveProgress();
  },

  transmitDataPacket: () => {
    const s = get();
    if (s.resources.dataStorage <= 0) {
      get().showToast(s.lang === 'ar' ? 'لا توجد بيانات مخزنة للبث حالياً.' : 'No buffered data to transmit.');
      return;
    }
    const commsMult = s.personnelEffects.commsRateMult;
    const packet = Math.min(s.resources.dataStorage, Math.round(120 * commsMult));
    set((state) => ({
      resources: {
        ...state.resources,
        dataStorage: Math.max(0, state.resources.dataStorage - packet),
        dataTransmitted: state.resources.dataTransmitted + packet,
        credits: state.resources.credits + Math.round(packet * 1.4 * commsMult),
        battery: Math.max(15, state.resources.battery - 4),
      },
    }));
    const msg = skyEventText('transmit', s.character.name, s.lang);
    get().pushSkyMessage(msg.text, msg.mood, true, msg.voiceText);
    spaceAudio.playRingPass();
    get().saveProgress();
  },

  cycleCommsStation: () => {
    const order: Array<ResourcesState['commsStation']> = ['Goldstone', 'Madrid', 'Canberra'];
    const s = get();
    const idx = order.indexOf(s.resources.commsStation);
    const next = order[(idx + 1) % order.length];
    const sigMap = { Goldstone: 94, Madrid: 89, Canberra: 97 };
    set({
      resources: {
        ...s.resources,
        commsStation: next,
        commsSignal: Math.min(100, Math.round(sigMap[next] * Math.min(1.06, s.personnelEffects.commsRateMult))),
      },
    });
    spaceAudio.playSkyChirp();
  },

  resolveEmergency: () => {
    const s = get();
    if (!s.emergency) return;
    const repairMult = s.personnelEffects.repairSpeedMult;
    const adjustedCost = Math.round(s.emergency.costCredits / Math.max(0.8, repairMult));
    set({
      emergency: null,
      resources: {
        ...s.resources,
        credits: Math.max(0, s.resources.credits - adjustedCost),
        battery: Math.min(100, s.resources.battery + Math.round(20 * repairMult)),
        suitO2: Math.min(100, s.resources.suitO2 + Math.round(25 * s.personnelEffects.lifeSupportRateMult)),
      },
    });
    const nLocal = getDisplayCommander(s.character.name, s.lang);
    const nEn = getEnglishCommander(s.character.name);
    const voiceText = `Well handled, ${nEn}. Emergency cleared and ship systems stabilized.`;
    get().pushSkyMessage(
      s.lang === 'ar'
        ? `أحسنت يا ${nLocal}! تمت معالجة الطارئ واستقرت أنظمة المركبة.`
        : voiceText,
      'happy',
      true,
      voiceText
    );
    spaceAudio.playRingPass();
  },

  resolveChoiceOption: (optionId) => {
    if (optionId === 'continue_roam') {
      set((state) => ({
        activeChoice: null,
        resources: { ...state.resources, credits: state.resources.credits + 250 },
      }));
      return;
    }
    set({ activeChoice: null });
    get().finishExpedition(true);
  },

  finishExpedition: (success, failureReason) => {
    const s = get();
    const score =
      s.survivalScore +
      s.discoveredPlanets.length * 250 +
      s.collectedSampleIds.length * 90 +
      s.completedScienceSiteIds.length * 140 +
      Math.round(s.resources.dataTransmitted * 2) +
      s.ringsPassed * 60 +
      s.asteroidsMined * 40 +
      (s.monolithInspected ? 450 : 0);

    const grade: MissionOutcome['grade'] = !success
      ? 'F'
      : score >= 2800
        ? 'S'
        : score >= 1700
          ? 'A'
          : score >= 900
            ? 'B'
            : 'C';

    const nLocal = getDisplayCommander(s.character.name, s.lang);

    set({
      screen: 'results',
      mode2dOpen: false,
      storyIntroOpen: false,
      missionOutcome: {
        success,
        score,
        grade,
        failureReason,
        endingTitle: success
          ? {
              ar: `انتصار البقاء للقائد ${nLocal}: نجاة نوفا-7`,
              en: `Survival Victory: Commander ${nLocal} Saved NOVA-7`,
            }
          : {
              ar: `خسارة المهمة: تدمير أو عجز سفينة القائد ${nLocal}`,
              en: `Mission Lost: NOVA-7 Critical Failure (${nLocal})`,
            },
        summary: success
          ? {
              ar: `أنجزت ${s.completedSurvivalIds.length}/${SURVIVAL_MISSIONS.length} من مهام البقاء الهندسية، وزرت ${s.discoveredPlanets.length}/6 عوالم وبثثت ${Math.round(s.resources.dataTransmitted)} MB عبر DSN.`,
              en: `Cleared ${s.completedSurvivalIds.length}/${SURVIVAL_MISSIONS.length} NASA & CSA survival missions, surveyed ${s.discoveredPlanets.length}/6 worlds, and downlinked ${Math.round(s.resources.dataTransmitted)} MB via DSN.`,
            }
          : {
              ar: failureReason?.ar ||
                `تجاوزت السفينة حد الإخفاقات الحرجة (${s.survivalFailures}/3) أو انهارت سلامة الهيكل (${Math.round(s.hullIntegrity)}%). أعد المحاولة من لوحة البقاء.`,
              en: failureReason?.en ||
                `Spacecraft suffered critical failures (${s.survivalFailures}/3 strikes) or Hull Integrity collapse (${Math.round(s.hullIntegrity)}%). Retry the survival campaign.`,
            },
      },
    });
  },

  setStoryIntroOpen: (storyIntroOpen) => {
    if (storyIntroOpen) engineBridge?.setMouseLocked(false);
    set({ storyIntroOpen });
  },

  setActiveSurvivalId: (activeSurvivalId) => set({ activeSurvivalId }),

  resolveSurvivalMission: (missionId, won, reasonText) => {
    const s = get();
    const m = SURVIVAL_MISSIONS.find((item) => item.id === missionId);
    if (!m) return;

    const sciMult = s.personnelEffects.scienceRateMult;
    const repMult = s.personnelEffects.repairSpeedMult;

    if (won) {
      const nextCompleted = s.completedSurvivalIds.includes(missionId)
        ? s.completedSurvivalIds
        : [...s.completedSurvivalIds, missionId];
      const nextFailed = s.failedSurvivalIds.filter((id) => id !== missionId);
      const nextHull = Math.min(100, s.hullIntegrity + Math.round(m.hullRestore * repMult));
      const nextBattery = Math.min(100, s.resources.battery + 15);
      const nextO2 = Math.min(100, s.resources.suitO2 + 15);
      const addedCredits = Math.round(m.rewardCredits * sciMult);
      const addedData = Math.round(m.rewardDataMb * sciMult);
      const nextScore = s.survivalScore + 350 + s.survivalStreak * 75;

      const remaining = SURVIVAL_MISSIONS.find((cand) => !nextCompleted.includes(cand.id));
      const nextCml = Math.min(4, Math.max(s.cmlLevel, nextCompleted.length >= 6 ? 4 : nextCompleted.length >= 3 ? 3 : 2)) as 1 | 2 | 3 | 4;

      set({
        hullIntegrity: nextHull,
        survivalStreak: s.survivalStreak + 1,
        survivalScore: nextScore,
        completedSurvivalIds: nextCompleted,
        failedSurvivalIds: nextFailed,
        activeSurvivalId: remaining ? remaining.id : missionId,
        cmlLevel: nextCml,
        resources: {
          ...s.resources,
          battery: nextBattery,
          suitO2: nextO2,
          credits: s.resources.credits + addedCredits,
          dataStorage: Math.min(s.resources.maxStorage, s.resources.dataStorage + addedData),
          dataCollected: s.resources.dataCollected + addedData,
        },
      });

      const nEn = getEnglishCommander(s.character.name);
      const voice = `Crisis resolved, ${nEn}! ${m.successSummary.en}`;
      get().pushSkyMessage(
        s.lang === 'ar' ? `✔ نجحت المهمة: ${m.successSummary.ar}` : voice,
        'excited',
        true,
        voice
      );
      spaceAudio.playPlanetFanfare();
      get().saveProgress();

      if (nextCompleted.length >= SURVIVAL_MISSIONS.length) {
        setTimeout(() => {
          if (get().screen === 'playing') {
            get().finishExpedition(true);
          }
        }, 700);
      }
      return;
    }

    // LOSS / PENALTY PATH
    const nextHull = Math.max(0, Math.round(s.hullIntegrity - m.hullPenalty));
    const nextBattery = Math.max(0, Math.round(s.resources.battery - m.powerPenalty));
    const nextO2 = Math.max(0, Math.round(s.resources.suitO2 - m.o2Penalty));
    const nextFailures = s.survivalFailures + 1;
    const nextFailed = s.failedSurvivalIds.includes(missionId)
      ? s.failedSurvivalIds
      : [...s.failedSurvivalIds, missionId];

    set({
      hullIntegrity: nextHull,
      survivalFailures: nextFailures,
      survivalStreak: 0,
      failedSurvivalIds: nextFailed,
      resources: {
        ...s.resources,
        battery: nextBattery,
        suitO2: nextO2,
      },
    });

    const nEn = getEnglishCommander(s.character.name);
    const voice = `Warning ${nEn}! Hull damage sustained. ${m.failureSummary.en}`;
    get().pushSkyMessage(
      s.lang === 'ar'
        ? `✖ إخفاق: ${reasonText?.ar || m.failureSummary.ar} (-${m.hullPenalty}% هيكل)`
        : `✖ Failure: ${reasonText?.en || m.failureSummary.en} (-${m.hullPenalty}% Hull)`,
      'warning',
      true,
      voice
    );
    spaceAudio.playWeatherAlert('storm');
    get().saveProgress();

    if (nextHull <= 0 || nextO2 <= 0 || nextBattery <= 0 || nextFailures >= 3) {
      const failReason: Record<Language, string> =
        nextHull <= 0
          ? {
              ar: 'انهيار سلامة الهيكل إلى 0% نتيجة الأعطال المتكررة أثناء الطوارئ.',
              en: 'Hull Integrity collapsed to 0% following unmitigated spacecraft damage.',
            }
          : nextO2 <= 0
            ? {
                ar: 'نفاد أكسجين المقصورة 0% — فشل دعم الحياة.',
                en: 'Cabin Life Support O2 reached 0% — critical life support loss.',
              }
            : nextBattery <= 0
              ? {
                  ar: 'انهيار طاقة المفاعل 0% — انطفاء كامل للمركبة.',
                  en: 'Reactor Power depleted to 0% — total spacecraft blackout.',
                }
              : {
                  ar: 'تجاوزت الحد الأقصى للأخطاء الهندسية الحرجة (3 إخفاقات بقاء) — تم إحباط البعثة!',
                  en: 'Reached 3 critical engineering failures — NOVA-7 survival protocol aborted!',
                };
      get().finishExpedition(false, failReason);
    }
  },

  retrySurvivalCampaign: () => {
    const s = get();
    set({
      screen: 'playing',
      missionOutcome: null,
      hullIntegrity: 100,
      survivalFailures: 0,
      survivalStreak: 0,
      completedSurvivalIds: [],
      failedSurvivalIds: [],
      activeSurvivalId: SURVIVAL_MISSIONS[0].id,
      resources: {
        ...s.resources,
        battery: 96,
        suitO2: 100,
        suitHealth: 100,
        suitCoolant: 100,
      },
      mode2dOpen: true,
      mode2dTab: 'dashboard2d',
    });
    spaceAudio.playSkyChirp();
    get().saveProgress();
  },

  openSurvivalDashboard2d: () => {
    engineBridge?.setMouseLocked(false);
    set({
      storyIntroOpen: false,
      architectOpen: false,
      mode2dOpen: true,
      mode2dTab: 'dashboard2d',
      tabletOpen: false,
      mapOpen: false,
      guideOpen: false,
      telescopeLabOpen: false,
      dashboardOpen: false,
    });
    spaceAudio.playSkyChirp();
  },

  setArchitectOpen: (open) => {
    if (open) engineBridge?.setMouseLocked(false);
    set({
      architectOpen: open,
      ...(open
        ? {
            storyIntroOpen: false,
            mode2dOpen: false,
            tabletOpen: false,
            mapOpen: false,
            guideOpen: false,
            dashboardOpen: false,
          }
        : {}),
    });
    spaceAudio.playSkyChirp();
  },

  recordArchitectRun: (run) => {
    const s = get();
    const updated = [run, ...s.architectRuns]
      .sort((a, b) => b.score - a.score)
      .slice(0, 16);
    try {
      localStorage.setItem(ARCHITECT_RUNS_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
    set({
      architectRuns: updated,
      survivalScore: s.survivalScore + (run.success ? Math.round(run.score * 0.25) : 40),
      resources: {
        ...s.resources,
        credits: s.resources.credits + (run.success ? 180 : 30),
        dataCollected: s.resources.dataCollected + (run.success ? 60 : 10),
      },
      toastText: run.success
        ? s.lang === 'ar'
          ? `تمت محاكاة المهمة بنجاح! رتبة ${run.grade} (${run.score} نقطة) +180 CR`
          : `Mission Simulation Passed! Grade ${run.grade} (${run.score} pts) +180 CR`
        : s.lang === 'ar'
          ? 'فشلت محاكاة التصميم — راجع التحليل السببي وأعد التصميم!'
          : 'Simulation Failed — inspect Post-Mission Causal Report & redesign!',
    });
    if (run.success) spaceAudio.playPlanetFanfare();
    else spaceAudio.playWeatherAlert('storm');
  },

  performAstronautAction: (action, value) => {
    const s = get();
    const bio = s.astronautBio;

    if (action === 'pace_breathing') {
      const nextBpm = Math.max(64, Math.round(bio.heartRateBpm - 18));
      const nextCo2 = Math.max(0.8, Number((bio.co2MmHg - 0.5).toFixed(1)));
      set({
        astronautBio: {
          ...bio,
          heartRateBpm: nextBpm,
          co2MmHg: nextCo2,
          stressLevel: nextBpm > 125 ? 'CRITICAL' : nextBpm > 105 ? 'HIGH' : nextBpm > 85 ? 'FOCUSED' : 'CALM',
        },
        toastText:
          s.lang === 'ar'
            ? 'تنفس إيقاعي 4-4-4: انخفض نبض رائد الفضاء واستقر التركيز.'
            : '4-4-4 Box Breathing: Heart rate steadied & stress lowered.',
      });
      spaceAudio.playSkyChirp();
      return;
    }

    if (action === 'purge_co2') {
      set({
        astronautBio: {
          ...bio,
          co2MmHg: 0.9,
          heartRateBpm: Math.max(68, Math.round(bio.heartRateBpm - 6)),
        },
        toastText:
          s.lang === 'ar'
            ? 'تم تطهير مرشح LiOH: هبط ثاني أكسيد الكربون إلى 0.9 mmHg.'
            : 'Metox / LiOH CO2 Scrubber purged cleanly (0.9 mmHg).',
      });
      spaceAudio.playSkyChirp();
      return;
    }

    if (action === 'prebreathe_o2') {
      set({
        astronautBio: {
          ...bio,
          preBreatheDone: true,
          suitPressureKpa: 29.6,
          co2MmHg: Math.max(0.8, Number((bio.co2MmHg - 0.4).toFixed(1))),
        },
        resources: {
          ...s.resources,
          suitO2: Math.min(100, s.resources.suitO2 + 12),
        },
        toastText:
          s.lang === 'ar'
            ? 'اكتمل التنفس المسبق بالأكسجين النقي (29.6 kPa) — آمن للسير الفضائي EVA!'
            : 'O2 Pre-Breathe & 29.6 kPa EMU pressure check verified for EVA!',
      });
      spaceAudio.playPlanetFanfare();
      return;
    }

    if (action === 'toggle_tether') {
      set({
        astronautBio: {
          ...bio,
          tetherLocked: !bio.tetherLocked,
        },
      });
      spaceAudio.playSkyChirp();
      return;
    }

    if (action === 'set_lcvg' && typeof value === 'number') {
      const clamped = Math.max(0, Math.min(100, value));
      set({
        astronautBio: {
          ...bio,
          lcvgCoolingPct: clamped,
        },
      });
      return;
    }

    if (action === 'set_temp_sim' && typeof value === 'number') {
      set({
        astronautBio: {
          ...bio,
          suitTempC: Number(value.toFixed(1)),
        },
      });
      return;
    }

    if (action === 'complete_eva_repair') {
      const nextRepairs = bio.evaRepairsCompleted + 1;
      const nextHull = Math.min(100, s.hullIntegrity + 15);
      set({
        hullIntegrity: nextHull,
        survivalScore: s.survivalScore + 180,
        astronautBio: {
          ...bio,
          evaRepairsCompleted: nextRepairs,
          heartRateBpm: Math.max(76, Math.round(bio.heartRateBpm - 8)),
        },
        resources: {
          ...s.resources,
          credits: s.resources.credits + 120,
        },
        toastText:
          s.lang === 'ar'
            ? 'تم إصلاح نقطة EVA الخارجية في انعدام الجاذبية (+15% هيكل، +120 CR)!'
            : 'Microgravity EVA hull repair complete! (+15% Hull Integrity, +120 CR)',
      });
      spaceAudio.playPlanetFanfare();
    }
  },

  stepEvaExertion: (dt, solarZone, thrusting) => {
    const s = get();
    const bio = s.astronautBio;
    // Target skin/suit temperature driven by Solar Sunlit (+58°C drift) vs Eclipse (-42°C drift) counteracted by LCVG cooling/heating loop
    const ambientDrive = solarZone === 'sunlit' ? 42 : -26;
    const lcvgBalance = (50 - bio.lcvgCoolingPct) * 0.48;
    const idealTemp = 21 + ambientDrive * 0.45 + lcvgBalance;
    const nextTemp = Number(
      (bio.suitTempC + (idealTemp - bio.suitTempC) * Math.min(1, dt * 0.85)).toFixed(1)
    );

    const co2Rise = (thrusting ? 0.34 : 0.11) * dt;
    const nextCo2 = Math.min(6.0, Number((bio.co2MmHg + co2Rise).toFixed(2)));
    const tempStress = Math.abs(nextTemp - 22) > 10 ? 18 : 0;
    const co2Stress = nextCo2 > 3.2 ? 22 : nextCo2 > 2.2 ? 9 : 0;
    const targetBpm = (thrusting ? 114 : 84) + tempStress + co2Stress + (!bio.preBreatheDone ? 12 : 0);
    const nextBpm = Math.max(
      62,
      Math.min(168, Math.round(bio.heartRateBpm + (targetBpm - bio.heartRateBpm) * Math.min(1, dt * 1.4)))
    );
    const stressLevel: AstronautBioState['stressLevel'] =
      nextBpm > 130 || nextCo2 > 4.0
        ? 'CRITICAL'
        : nextBpm > 108 || nextCo2 > 2.8
          ? 'HIGH'
          : nextBpm > 86
            ? 'FOCUSED'
            : 'CALM';

    set({
      astronautBio: {
        ...bio,
        heartRateBpm: nextBpm,
        co2MmHg: nextCo2,
        suitTempC: nextTemp,
        stressLevel,
      },
      resources: {
        ...s.resources,
        suitO2: Math.max(8, Number((s.resources.suitO2 - (thrusting ? 0.85 : 0.25) * dt).toFixed(2))),
      },
    });
  },

  toggleMute: () => {
    const s = get();
    const next = !s.audioMuted;
    spaceAudio.setMuted(next);
    set({ audioMuted: next });
    persistAudioPrefs({
      audioMuted: next,
      ambientHumEnabled: s.ambientHumEnabled,
      roverAudioEnabled: s.roverAudioEnabled,
      speechEnabled: s.speechEnabled,
    });
  },

  toggleAmbientHum: () => {
    const s = get();
    const next = !s.ambientHumEnabled;
    spaceAudio.setAmbientHumEnabled(next);
    set({ ambientHumEnabled: next });
    persistAudioPrefs({
      audioMuted: s.audioMuted,
      ambientHumEnabled: next,
      roverAudioEnabled: s.roverAudioEnabled,
      speechEnabled: s.speechEnabled,
    });
  },

  toggleRoverAudio: () => {
    const s = get();
    const next = !s.roverAudioEnabled;
    spaceAudio.setRoverAudioEnabled(next);
    set({ roverAudioEnabled: next });
    persistAudioPrefs({
      audioMuted: s.audioMuted,
      ambientHumEnabled: s.ambientHumEnabled,
      roverAudioEnabled: next,
      speechEnabled: s.speechEnabled,
    });
  },

  toggleSpeech: () => {
    const s = get();
    const next = !s.speechEnabled;
    spaceAudio.setSpeechEnabled(next);
    set({ speechEnabled: next });
    persistAudioPrefs({
      audioMuted: s.audioMuted,
      ambientHumEnabled: s.ambientHumEnabled,
      roverAudioEnabled: s.roverAudioEnabled,
      speechEnabled: next,
    });
  },

  toggleShadows: () => set((s) => ({ shadowsEnabled: !s.shadowsEnabled })),

  updateSettings: (patch) => {
    const s = get();
    const next: GameSettings = { ...s.settings, ...patch };
    if (typeof patch.masterVolume === 'number') {
      spaceAudio.setMasterVolume(next.masterVolume);
    }
    persistSettings(next);
    set({ settings: next });
    engineBridge?.applySettings(next);
  },

  applyQualityPreset: (preset) => {
    const presetMap: Record<
      QualityPreset,
      { resolutionScale: number; bloomEnabled: boolean; shadowsEnabled: boolean }
    > = {
      low: { resolutionScale: 0.75, bloomEnabled: false, shadowsEnabled: false },
      medium: { resolutionScale: 1, bloomEnabled: false, shadowsEnabled: true },
      high: { resolutionScale: 1, bloomEnabled: true, shadowsEnabled: true },
      ultra: { resolutionScale: 1.5, bloomEnabled: true, shadowsEnabled: true },
    };
    const cfg = presetMap[preset];
    const s = get();
    const next: GameSettings = {
      ...s.settings,
      qualityPreset: preset,
      resolutionScale: cfg.resolutionScale,
      bloomEnabled: cfg.bloomEnabled,
    };
    persistSettings(next);
    set({ settings: next, shadowsEnabled: cfg.shadowsEnabled });
    engineBridge?.applySettings(next);
  },

  simulationTick: (dt) => {
    const s = get();
    if (s.screen !== 'playing') return;

    const { repairSpeedMult, lifeSupportRateMult, commsRateMult } = s.personnelEffects;
    const planetBuildings = s.surfaceBuildings.filter((b) => b.planetId === s.activePlanet);
    const habitatBonus = planetBuildings.filter((b) => b.kind === 'habitat').length * 1.6;
    const solarBonus = planetBuildings.filter((b) => b.kind === 'solar_relay').length * 1.4;
    const beaconBonus = planetBuildings.filter((b) => b.kind === 'science_beacon').length * 1.8;

    const onPlanet = s.sceneEnv === 'planet';
    const nearShipPad = onPlanet && Boolean(s.surfaceTelemetry.nearShipPad);

    let nextBattery = s.resources.battery;
    let nextO2 = s.resources.suitO2;
    let nextHealth = s.resources.suitHealth ?? 100;
    let nextCoolant = s.resources.suitCoolant ?? 100;

    if (onPlanet) {
      if (nearShipPad) {
        // Spacecraft Umbilical Refuel Zone: actively tops up O2, Power, Coolant & Suit Health
        nextO2 = Math.min(100, nextO2 + 12 * dt);
        nextBattery = Math.min(100, nextBattery + 10 * dt);
        nextCoolant = Math.min(100, nextCoolant + 12 * dt);
        nextHealth = Math.min(100, nextHealth + 7 * dt);
      } else {
        const o2Drain = (s.pilotingRover ? -0.22 : s.activePlanet === 'aurora' ? -0.24 : -0.52) + habitatBonus;
        const pwrDrain = (s.pilotingRover ? -0.45 : -0.22) + solarBonus;
        const coolDrain = s.pilotingRover ? -0.15 : -0.35;
        nextO2 = Math.max(0, Math.min(100, nextO2 + o2Drain * dt));
        nextBattery = Math.max(0, Math.min(100, nextBattery + pwrDrain * dt));
        nextCoolant = Math.max(0, Math.min(100, nextCoolant + coolDrain * dt));
        if (nextCoolant <= 0) {
          // Overheating suit slowly degrades suit health if coolant runs dry
          nextHealth = Math.max(0, nextHealth - 1.5 * dt);
        }
      }
    } else if (s.sceneEnv === 'interior') {
      nextBattery = Math.min(100, nextBattery + 2.5 * repairSpeedMult * dt);
      nextO2 = Math.min(100, nextO2 + 5 * lifeSupportRateMult * dt);
      nextCoolant = Math.min(100, nextCoolant + 5 * lifeSupportRateMult * dt);
      nextHealth = Math.min(100, nextHealth + 4 * lifeSupportRateMult * dt);
    } else {
      const netRatio = s.shipMetrics.netPower >= 0 ? 0.45 * repairSpeedMult : -0.85;
      const batteryDrain = (s.spaceTelemetry.boosting ? -1.4 : netRatio) * dt;
      nextBattery = Math.max(8, Math.min(100, nextBattery + batteryDrain));
      nextO2 = Math.min(100, nextO2 + 3.2 * lifeSupportRateMult * dt);
    }

    let nextDataStorage = Math.min(
      s.resources.maxStorage,
      s.resources.dataStorage + (onPlanet ? beaconBonus * dt : 0)
    );
    let nextDataCollected = s.resources.dataCollected + (onPlanet ? beaconBonus * dt : 0);
    let nextDataTransmitted = s.resources.dataTransmitted;
    if (s.missionPlan.autoTransmit && nextDataStorage > 20) {
      const tx = Math.min(nextDataStorage, 12 * commsRateMult * dt);
      nextDataStorage -= tx;
      nextDataTransmitted += tx;
    }

    const bio = s.astronautBio;
    const hazardStress =
      s.spaceTelemetry.hazardLevel === 'SEVERE'
        ? 26
        : s.spaceTelemetry.hazardLevel === 'ELEVATED'
          ? 12
          : 0;
    const envTargetBpm =
      onPlanet && !s.pilotingRover
        ? (s.surfaceTelemetry.hostileAlienDist !== null ? 118 : 88) + hazardStress
        : s.sceneEnv === 'spaceflight' && s.spaceTelemetry.boosting
          ? 96 + hazardStress
          : 72 + hazardStress + s.survivalFailures * 8;
    const nextBpm = Math.round(bio.heartRateBpm + (envTargetBpm - bio.heartRateBpm) * Math.min(1, dt * 0.6));
    const co2Delta = nearShipPad || s.sceneEnv === 'interior' ? -0.35 * dt : onPlanet && !s.pilotingRover ? 0.05 * dt : -0.04 * dt;
    const nextCo2 = Math.max(0.8, Math.min(5.5, Number((bio.co2MmHg + co2Delta).toFixed(2))));
    const stressLevel: AstronautBioState['stressLevel'] =
      nextBpm > 130 || nextHealth < 35 || nextO2 < 25
        ? 'CRITICAL'
        : nextBpm > 108
          ? 'HIGH'
          : nextBpm > 86
            ? 'FOCUSED'
            : 'CALM';

    set({
      resources: {
        ...s.resources,
        battery: nextBattery,
        suitO2: nextO2,
        suitHealth: nextHealth,
        suitCoolant: nextCoolant,
        solTime: s.resources.solTime + dt * 0.04,
        dataStorage: nextDataStorage,
        dataCollected: nextDataCollected,
        dataTransmitted: nextDataTransmitted,
      },
      astronautBio: {
        ...bio,
        heartRateBpm: nextBpm,
        co2MmHg: nextCo2,
        stressLevel,
      },
    });

    if (onPlanet && (nextO2 <= 0 || nextHealth <= 0)) {
      get().finishExpedition(false, {
        ar:
          nextO2 <= 0
            ? 'نفد أكسجين بدلة الفضاء بالكامل (0%) قبل العودة إلى المركبة الفضائية لإعادة التعبئة.'
            : 'فقد رائد الفضاء كامل صحة البدلة (0%) على سطح الكوكب قبل العودة إلى المركبة.',
        en:
          nextO2 <= 0
            ? 'EVA Suit Oxygen reached 0% on the planet surface before returning to the spacecraft to refuel.'
            : 'Astronaut Suit Health dropped to 0% on the planet surface before returning to the spacecraft.',
      });
    }
  },
}));
